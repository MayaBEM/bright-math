import type { WorldId } from '../types';

interface Props { world: WorldId; size?: number; className?: string; }

/** Original simple scene per world. Uses currentColor for the accent. */
export function WorldArt({ world, size = 96, className }: Props) {
  const common = { width: size, height: size, viewBox: '0 0 120 120', className,
    xmlns: 'http://www.w3.org/2000/svg', 'aria-hidden': true as const };
  const soft = 'rgba(255,255,255,0.55)';
  switch (world) {
    case 'w1': // All About Me — mirror & person
      return (
        <svg {...common}>
          <circle cx="60" cy="60" r="52" fill={soft} />
          <circle cx="60" cy="48" r="16" fill="currentColor" />
          <path d="M34 92c0-16 12-24 26-24s26 8 26 24" fill="currentColor" />
          <circle cx="60" cy="48" r="16" fill="none" stroke="#fff" strokeWidth="3" opacity=".5" />
        </svg>
      );
    case 'w2': // Favorite Things — heart & star
      return (
        <svg {...common}>
          <circle cx="60" cy="60" r="52" fill={soft} />
          <path d="M60 88C40 74 30 64 30 51c0-9 7-15 15-15 6 0 11 4 15 10 4-6 9-10 15-10 8 0 15 6 15 15 0 13-10 23-30 37z" fill="currentColor" />
          <path d="M84 34l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z" fill="#fff" opacity=".7" />
        </svg>
      );
    case 'w3': // Family & Friends — two people
      return (
        <svg {...common}>
          <circle cx="60" cy="60" r="52" fill={soft} />
          <circle cx="45" cy="50" r="12" fill="currentColor" />
          <circle cx="76" cy="54" r="10" fill="currentColor" />
          <path d="M28 92c0-13 8-20 17-20s17 7 17 20z" fill="currentColor" />
          <path d="M60 92c0-11 7-17 16-17s16 6 16 17z" fill="currentColor" opacity=".85" />
        </svg>
      );
    case 'w4': // Feelings & My Day — sun with face
      return (
        <svg {...common}>
          <circle cx="60" cy="60" r="52" fill={soft} />
          {Array.from({ length: 12 }).map((_, i) => {
            const a = (i * 30 * Math.PI) / 180;
            return <line key={i} x1={60 + Math.cos(a) * 30} y1={60 + Math.sin(a) * 30}
              x2={60 + Math.cos(a) * 42} y2={60 + Math.sin(a) * 42}
              stroke="currentColor" strokeWidth="5" strokeLinecap="round" />;
          })}
          <circle cx="60" cy="60" r="26" fill="currentColor" />
          <circle cx="52" cy="56" r="3.4" fill="#fff" />
          <circle cx="68" cy="56" r="3.4" fill="#fff" />
          <path d="M50 66c5 6 15 6 20 0" fill="none" stroke="#fff" strokeWidth="3.4" strokeLinecap="round" />
        </svg>
      );
    case 'w5': // Dreams & Tomorrow — rocket & star
      return (
        <svg {...common}>
          <circle cx="60" cy="60" r="52" fill={soft} />
          <path d="M60 26c12 6 18 20 18 34l-8 8H50l-8-8c0-14 6-28 18-34z" fill="currentColor" />
          <circle cx="60" cy="52" r="7" fill="#fff" opacity=".85" />
          <path d="M50 78l-8 12 12-4zM70 78l8 12-12-4z" fill="currentColor" opacity=".8" />
        </svg>
      );
  }
}
