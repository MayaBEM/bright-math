import { useState } from 'react';
import { NavLink, Link, Outlet } from 'react-router-dom';
import { Menu, X, Map, GraduationCap, Sparkles } from 'lucide-react';
import { Brighty } from '../art/Brighty';
import { SoundPanel } from './SoundPanel';

const LINKS: { to: string; label: string }[] = [
  { to: '/modes', label: 'Modes' },
  { to: '/map', label: 'Learning Map' },
  { to: '/quiz', label: 'Review Quiz' },
  { to: '/progress', label: 'Progress' },
  { to: '/classroom', label: 'Classroom' },
  { to: '/teacher-guide', label: 'Teacher Guide' },
  { to: '/print', label: 'Printables' },
];

export function Layout() {
  const [open, setOpen] = useState(false);
  return (
    <div className="app-shell">
      <a href="#main" className="skip-link">Skip to content</a>
      <header className="app-nav no-print">
        <div className="container app-nav__row">
          <Link to="/" className="brand" aria-label="Bright Talk Adventure home">
            <Brighty size={40} mood="happy" />
            <span>
              <span className="brand__name">Bright Talk Adventure</span><br />
              <span className="brand__tag">25 Daily Conversation Missions</span>
            </span>
          </Link>
          <button className="btn btn--ghost btn--icon nav-toggle" aria-label="Toggle menu"
            aria-expanded={open} onClick={() => setOpen((o) => !o)}>
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
          <nav className="nav-links" aria-label="Main" onClick={() => setOpen(false)}
            data-open={String(open)}>
            {LINKS.map((l) => (
              <NavLink key={l.to} to={l.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
                {l.label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>

      <main id="main" className="page">
        <Outlet />
      </main>

      <footer className="app-footer no-print">
        <div className="container">
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 8 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><Map size={16} /> Learning Map</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><Sparkles size={16} /> Interactive Games</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><GraduationCap size={16} /> Teacher Tools</span>
          </div>
          <strong>Bright Talk Adventure</strong><br />
          Created by Bright EngMath · For classroom and educational use
        </div>
      </footer>

      <SoundPanel />
    </div>
  );
}
