import { Brighty } from '../art/Brighty';

const SECTIONS = [
  { id: 'how', title: 'How to use the website' },
  { id: 'one', title: 'One-to-one lesson ideas' },
  { id: 'group', title: 'Small group lesson ideas' },
  { id: 'class', title: 'Whole-class activity ideas' },
  { id: 'flow', title: 'Suggested lesson flow' },
  { id: 'levels', title: 'Using the three support levels' },
  { id: 'assess', title: 'Speaking assessment checklist' },
  { id: 'privacy', title: 'Privacy note for voice recording' },
  { id: 'print', title: 'How to print the materials' },
  { id: 'reset', title: 'How to reset progress' },
];

export function TeacherGuidePage() {
  return (
    <div className="container guide">
      <div className="page-head">
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 6 }}><Brighty mood="talk" size={90} /></div>
        <h1>Teacher Guide</h1>
        <p>Everything you need to run confident, low-prep speaking lessons with Bright Talk Adventure.</p>
      </div>

      <nav className="toc" aria-label="Guide contents">
        {SECTIONS.map((s) => (
          <a key={s.id} href={`#${s.id}`} className="chip">{s.title}</a>
        ))}
      </nav>

      <section id="how">
        <h2>How to use the website</h2>
        <p>Bright Talk Adventure turns 25 everyday questions into speaking missions across five worlds. There is no login and nothing to install — open it in a browser and start. Progress saves automatically on the device you are using. Choose an activity from the Modes page: Learn &amp; Speak for guided practice, Pick a Card or Spin &amp; Speak for playful review, Classroom Mode for the big screen, and the Review Quiz to check understanding.</p>
      </section>

      <section id="one">
        <h2>One-to-one lesson ideas</h2>
        <ul>
          <li>Open Learn &amp; Speak and set the support level to match the learner. Listen together, then have the child answer aloud.</li>
          <li>Use the Record button so the learner can hear themselves and try again with more detail.</li>
          <li>Finish with the follow-up question to stretch the conversation a little further.</li>
        </ul>
      </section>

      <section id="group">
        <h2>Small group lesson ideas</h2>
        <ul>
          <li>Use Pick a Card and let each child flip a card and answer, then pass to the next learner.</li>
          <li>Play in pairs: one child asks the question on screen, the other answers, then they swap roles.</li>
          <li>Award points with the Speaking Checklist — one tick for each thing the learner remembered to do.</li>
        </ul>
      </section>

      <section id="class">
        <h2>Whole-class activity ideas</h2>
        <ul>
          <li>Open Classroom Mode on the projector or interactive screen. Add your students' names once and reuse them all term.</li>
          <li>Use the Random Student picker and a 30-second timer to keep turns fair and lively.</li>
          <li>Give a star for good sentences, and reveal the model answer only after the class has tried.</li>
        </ul>
      </section>

      <section id="flow">
        <h2>Suggested lesson flow</h2>
        <ol>
          <li><strong>Warm-up</strong> — greet the class and spin the wheel for one easy question.</li>
          <li><strong>Listen and repeat</strong> — play the question with Listen, then Slow, and have learners repeat.</li>
          <li><strong>Model answer</strong> — show the short and extended answers and read them together.</li>
          <li><strong>Student speaking</strong> — each learner answers in a full sentence.</li>
          <li><strong>Follow-up question</strong> — extend the conversation with the follow-up.</li>
          <li><strong>Quick review quiz</strong> — do a few quiz items to check understanding.</li>
          <li><strong>Reflection</strong> — ask "What did you learn today?" and tick the Speaking Checklist.</li>
        </ol>
      </section>

      <section id="levels">
        <h2>Using the three support levels</h2>
        <p>Every question in Learn &amp; Speak can be shown at three levels of support. Change the level at any time to match the learner in front of you.</p>
        <ul>
          <li><strong>Level 1 — Picture Support:</strong> illustration, vocabulary chips and a full sentence starter. Best for beginners and pre-readers.</li>
          <li><strong>Level 2 — Sentence Support:</strong> sentence starter and key vocabulary, with the model answer hidden until needed.</li>
          <li><strong>Level 3 — Speak Freely:</strong> just the question and a follow-up, for learners who are ready to talk more independently.</li>
        </ul>
      </section>

      <section id="assess">
        <h2>Speaking assessment checklist</h2>
        <p>Because these are open-ended questions, there is no single "right" answer. Instead, assess the learner's speaking with four friendly points:</p>
        <ul>
          <li>I tried to answer.</li>
          <li>I used a full sentence.</li>
          <li>I spoke clearly.</li>
          <li>I added one extra detail.</li>
        </ul>
        <p>Ticks are saved and summarised on the Progress page, so you can see growth over time without comparing children to one another.</p>
      </section>

      <section id="privacy">
        <h2>Privacy note for voice recording</h2>
        <p>The Record feature uses your browser's microphone. Recordings stay in the browser's memory on the current device and are <strong>never uploaded to any server</strong>. They are cleared when the learner presses Delete, moves to another question, or closes the page. If the microphone is blocked, learners can still practise out loud — recording is optional. For young children, always follow your school's own consent and safeguarding policy before recording voices.</p>
      </section>

      <section id="print">
        <h2>How to print the materials</h2>
        <p>Open the Printables page and choose a document: question cards, the student speaking checklist, a teacher observation sheet, a pair-work activity, the favorite-answers worksheet, or a certificate. Click Print (or press Ctrl/Cmd + P) and select A4. A dedicated print stylesheet hides all buttons and navigation, keeps cards whole, and uses light ink. The Bright EngMath credit appears politely on every page.</p>
      </section>

      <section id="reset">
        <h2>How to reset progress</h2>
        <p>Student progress (missions, badges, quiz scores and checklists) can be cleared on the Progress page with the Reset Progress button. Classroom names and stars are stored separately and are cleared with Clear Class Data in Classroom Mode. Both actions ask for confirmation first, and neither affects any other device.</p>
      </section>

      <p style={{ textAlign: 'center', color: 'var(--ink-soft)', marginTop: 30 }}>
        <strong>Bright Talk Adventure</strong> · Created by Bright EngMath · For classroom and educational use
      </p>
    </div>
  );
}
