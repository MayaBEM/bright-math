interface Props { id: number; size?: number; className?: string; }

/** Small original line illustration per question. Uses currentColor. */
export function QuestionArt({ id, size = 120, className }: Props) {
  const p = { fill: 'none', stroke: 'currentColor', strokeWidth: 5,
    strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
  const c = (x: number, y: number, r: number, extra?: object) =>
    <circle cx={x} cy={y} r={r} {...p} {...extra} />;
  const svg = (children: React.ReactNode) => (
    <svg width={size} height={size} viewBox="0 0 120 120" className={className}
      xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <rect x="8" y="8" width="104" height="104" rx="24" fill="rgba(255,255,255,0.55)" />
      {children}
    </svg>
  );
  switch (id) {
    case 1: return svg(<><path d="M40 44h40M40 60h40M40 76h24" {...p} /><path d="M28 32h64v56H28z" {...p} /></>); // name tag lines
    case 2: return svg(<><path d="M34 60h52v28H34z" {...p} /><path d="M34 60c0-8 6-12 26-12s26 4 26 12" {...p} /><path d="M60 36v10M50 40v8M70 40v8" {...p} /></>); // cake
    case 3: return svg(<><path d="M60 44c-14-16-40 2-24 18l24 24 24-24c16-16-10-34-24-18z" {...p} /></>); // hello heart wave -> heart
    case 12: return svg(<><path d="M32 62l28-24 28 24" {...p} /><path d="M40 60v28h40V60" {...p} /><path d="M54 88V70h12v18" {...p} /></>); // house
    case 19: return svg(<><path d="M30 54l30-16 30 16-30 16z" {...p} /><path d="M44 62v18c0 4 32 4 32 0V62" {...p} /></>); // school/graduation
    case 4: return svg(<><path d="M60 30c17 0 30 12 30 27 0 10-9 13-16 13-5 0-7 3-7 7 0 6-3 8-8 8-16 0-29-13-29-28s13-27 30-27z" {...p} />{c(46,52,3,{fill:'currentColor'})}{c(60,44,3,{fill:'currentColor'})}{c(74,52,3,{fill:'currentColor'})}</>); // palette
    case 5: return svg(<><path d="M30 56h60c0 18-14 30-30 30S30 74 30 56z" {...p} /><path d="M60 40v10M50 44v8M70 44v8" {...p} /></>); // bowl
    case 6: return svg(<><path d="M60 46c8-8 24-6 24 12 0 16-12 30-24 30S36 74 36 58c0-18 16-20 24-12z" {...p} /><path d="M60 46c0-8 4-12 10-14" {...p} /></>); // apple
    case 7: return svg(<>{c(60,60,26)}{c(48,52,4,{fill:'currentColor'})}{c(72,52,4,{fill:'currentColor'})}<path d="M50 70c6 6 14 6 20 0" {...p} /><path d="M40 40l8 8M80 40l-8 8" {...p} /></>); // teddy
    case 11: return svg(<>{c(60,64,24)}<path d="M42 46l6 14M78 46l-6 14" {...p} /><path d="M52 66l-8 4M68 66l8 4M52 70l-8-1M68 70l8-1" {...p} /></>); // cat
    case 8: return svg(<>{c(45,50,10)}{c(75,54,8)}<path d="M32 88c0-12 6-18 13-18s13 6 13 18M62 88c0-10 6-15 13-15s13 5 13 15" {...p} /></>); // family
    case 21: return svg(<>{c(48,50,10)}{c(72,50,10)}<path d="M34 86c0-11 6-16 14-16s14 5 14 16M58 86c0-11 6-16 14-16s14 5 14 16" {...p} /></>); // friends
    case 9: return svg(<>{c(44,74,12)}{c(80,74,12)}<path d="M44 74l14-26h16M58 48l10 26" {...p} /></>); // bike
    case 15: return svg(<><path d="M60 40c-8-6-20-6-26 0v40c6-6 18-6 26 0 8-6 20-6 26 0V40c-6-6-18-6-26 0z" {...p} /><path d="M60 40v40" {...p} /></>); // book/story
    case 18: return svg(<><path d="M34 44h52v34H34z" {...p} /><path d="M50 88h20M60 78v10" {...p} />{c(52,60,4,{fill:'currentColor'})}{c(68,60,4,{fill:'currentColor'})}</>); // tv/cartoon
    case 10: return svg(<><path d="M40 44h32l8 8v36H40z" {...p} /><path d="M50 60h20M50 72h14" {...p} /><path d="M72 44v8h8" {...p} /></>); // learn paper
    case 13: return svg(<>{c(60,60,26)}{c(50,54,3,{fill:'currentColor'})}{c(70,54,3,{fill:'currentColor'})}<path d="M48 66c6 8 18 8 24 0" {...p} /></>); // happy face
    case 14: return svg(<>{c(60,60,26)}{c(50,54,3,{fill:'currentColor'})}{c(70,54,3,{fill:'currentColor'})}<path d="M48 74c6-8 18-8 24 0" {...p} /></>); // sad face
    case 16: return svg(<>{c(50,54,14)}<path d="M62 66h18c8 0 12 5 12 11s-5 11-12 11H44c-8 0-14-5-14-12s6-12 13-12" {...p} /></>); // weather sun+cloud
    case 20: return svg(<><path d="M52 74V40l24-6v34" {...p} />{c(46,74,7)}{c(70,68,7)}</>); // music note
    case 17: return svg(<><path d="M60 32l7 16 17 1-13 11 4 17-15-9-15 9 4-17-13-11 17-1z" {...p} /></>); // star/dream job
    case 22: return svg(<><path d="M34 44h52v44H34z" {...p} /><path d="M34 56h52M46 38v10M74 38v10" {...p} /><path d="M52 70l6 6 12-12" {...p} /></>); // calendar tomorrow
    case 23: return svg(<><path d="M40 40h34c4 0 6 2 6 6v40H46c-4 0-6-2-6-6z" {...p} /><path d="M40 40v40" {...p} /><path d="M52 54h18M52 64h14" {...p} /></>); // book
    case 24: return svg(<><path d="M60 34c10 12 6 22-2 22 6-4 2-12-2-14 2 8-8 10-8 18 0 10 6 16 14 16s14-6 14-16c0-16-8-30-16-26z" {...p} /></>); // leaf/season
    case 25: return svg(<><path d="M60 34v22M60 64v22M38 60h22M60 60h22" {...p} /><path d="M46 46l28 28M74 46L46 74" {...p} opacity="0.5" /></>); // sparkle/new
    default: return svg(c(60, 60, 26));
  }
}
