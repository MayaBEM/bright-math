import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Volume2, Check, X, ArrowRight, RotateCcw, ChevronLeft, ListChecks, Delete, PartyPopper } from 'lucide-react';
import { useApp } from '../store/AppContext';
import { QUIZ, QUIZ_TYPE_LABEL } from '../data/quiz';
import { worldOfQuestion } from '../data/worlds';
import type { QuizQuestion } from '../types';
import { useSpeech } from '../hooks/useSpeech';
import { useSfx } from '../hooks/useSfx';
import { Confetti } from '../art/Confetti';

const LETTERS = ['A', 'B', 'C', 'D'];

type Phase = 'answering' | 'retry' | 'revealed';

export function QuizPage() {
  const nav = useNavigate();
  const { speak } = useSpeech();
  const { play } = useSfx();
  const { recordQuiz } = useApp();

  const [i, setI] = useState(0);
  const [phase, setPhase] = useState<Phase>('answering');
  const [chosen, setChosen] = useState<number | null>(null);
  const [results, setResults] = useState<Record<number, boolean>>({});   // id -> firstTryCorrect
  const [tray, setTray] = useState<string[]>([]);                        // for order type
  const [finished, setFinished] = useState(false);

  const q = QUIZ[i];
  const world = worldOfQuestion(q.id);
  const answeredCount = Object.keys(results).length;
  const score = Object.values(results).filter(Boolean).length;

  const resetForNext = () => { setPhase('answering'); setChosen(null); setTray([]); };

  const commit = (correct: boolean, firstTry: boolean) => {
    setResults((r) => (q.id in r ? r : { ...r, [q.id]: correct && firstTry }));
  };

  const choose = (index: number) => {
    if (phase === 'revealed') return;
    setChosen(index);
    const correct = index === q.correctIndex;
    if (correct) {
      play('success');
      commit(true, phase === 'answering');
      setPhase('revealed');
    } else if (phase === 'answering') {
      play('click');
      commit(false, false);           // first-try wrong: no point even if later correct
      setPhase('retry');
      window.setTimeout(() => setChosen(null), 900);
    } else {
      setPhase('revealed');           // second wrong: reveal answer
    }
  };

  // ----- order type helpers -----
  const addWord = (w: string, idx: number) => {
    if (phase === 'revealed') return;
    setTray((t) => [...t, w]);
    setBank((b) => b.filter((_, bi) => bi !== idx));
  };
  const [bank, setBank] = useState<string[]>(() => (q.type === 'order' ? [...(q.words ?? [])] : []));
  const removeWord = (idx: number) => {
    if (phase === 'revealed') return;
    setBank((b) => [...b, tray[idx]]);
    setTray((t) => t.filter((_, ti) => ti !== idx));
  };
  const checkOrder = () => {
    const norm = (v: string) => v.replace(/[.,!?]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
    const correct = norm(tray.join(' ')) === norm(q.answer);
    if (correct) { play('success'); commit(true, phase === 'answering'); setPhase('revealed'); }
    else if (phase === 'answering') { play('click'); commit(false, false); setPhase('retry'); }
    else { setPhase('revealed'); }
  };

  const next = () => {
    if (i < QUIZ.length - 1) {
      const ni = i + 1;
      setI(ni);
      resetForNext();
      setBank(QUIZ[ni].type === 'order' ? [...(QUIZ[ni].words ?? [])] : []);
    } else {
      const incorrect = QUIZ.filter((qq) => !results[qq.id]).map((qq) => qq.id);
      recordQuiz(score, incorrect);
      play('celebrate');
      setFinished(true);
    }
  };

  const restart = () => {
    setI(0); setResults({}); resetForNext();
    setBank(QUIZ[0].type === 'order' ? [...(QUIZ[0].words ?? [])] : []);
    setFinished(false);
  };

  const incorrectList = useMemo(() => QUIZ.filter((qq) => !results[qq.id]), [results]);

  if (finished) {
    const pct = Math.round((score / QUIZ.length) * 100);
    const msg = pct >= 80 ? 'Fantastic work! You really know your conversations.'
      : pct >= 50 ? 'Great effort! Your English is growing stronger.'
      : 'Good try! Practice a little more and you will get even better.';
    return (
      <div className="container quiz-wrap quiz-result">
        <Confetti show={pct >= 60} />
        <div className="card">
          <PartyPopper size={40} color="var(--coral)" />
          <h1 style={{ marginTop: 8 }}>Quiz Complete!</h1>
          <div className="score-ring">{score} / {QUIZ.length}</div>
          <p className="encourage" style={{ marginTop: 12 }}>{msg}</p>

          {incorrectList.length > 0 && (
            <div style={{ textAlign: 'left', marginTop: 18 }}>
              <h3 style={{ marginBottom: 8 }}>Review these questions</h3>
              {incorrectList.map((qq) => (
                <div key={qq.id} className="example-box" style={{ marginBottom: 10 }}>
                  <h4>{QUIZ_TYPE_LABEL[qq.type]}</h4>
                  <p style={{ marginBottom: 6 }}>{qq.prompt}</p>
                  <p style={{ marginBottom: 0, color: '#0f4030', fontWeight: 800 }}>
                    <Check size={16} style={{ verticalAlign: '-3px' }} /> {qq.answer}
                  </p>
                </div>
              ))}
            </div>
          )}

          <div className="cls-toolbar" style={{ marginTop: 18 }}>
            <button className="btn btn--primary" onClick={restart}><RotateCcw size={18} /> Restart Quiz</button>
            <button className="btn btn--soft" onClick={() => nav('/progress')}>See Progress <ArrowRight size={16} /></button>
            <button className="btn btn--ghost" onClick={() => nav('/modes')}>Back to Activities</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container quiz-wrap" style={{ ['--wc' as string]: world.color }}>
      <button className="back-link" onClick={() => nav('/modes')}><ChevronLeft size={18} /> Back to Activities</button>
      <div className="quiz-top">
        <ListChecks size={22} color="var(--ocean)" />
        <div className="progress" style={{ flex: 1 }} aria-hidden="true">
          <span style={{ width: `${(i / QUIZ.length) * 100}%` }} />
        </div>
        <span className="counter">Q {i + 1} / {QUIZ.length} · Score {score}</span>
      </div>

      <div className="card">
        <div className="quiz-type">{QUIZ_TYPE_LABEL[q.type]}</div>
        <h2 className="quiz-prompt">{q.prompt}</h2>

        {q.type === 'listen' && (
          <div style={{ textAlign: 'center', marginBottom: 16 }}>
            <button className="btn btn--primary btn--lg" onClick={() => speak(q.listenText ?? q.answer)}>
              <Volume2 size={20} /> Listen
            </button>
          </div>
        )}

        {q.type === 'order' ? (
          <OrderUI tray={tray} bank={bank} phase={phase} answer={q.answer}
            onAdd={addWord} onRemove={removeWord} onCheck={checkOrder} onSpeak={() => speak(q.answer)} />
        ) : (
          <div className="choices">
            {q.choices.map((c, idx) => {
              const isChosen = chosen === idx;
              const reveal = phase === 'revealed';
              const cls = reveal && idx === q.correctIndex ? ' correct'
                : (isChosen && idx !== q.correctIndex) ? ' wrong' : '';
              return (
                <button key={idx} className={`choice${cls}`} disabled={reveal}
                  aria-label={`Option ${LETTERS[idx]}: ${c}`} onClick={() => choose(idx)}>
                  <span className="k">{reveal && idx === q.correctIndex ? <Check size={18} /> : (isChosen && idx !== q.correctIndex) ? <X size={18} /> : LETTERS[idx]}</span>
                  {c}
                </button>
              );
            })}
          </div>
        )}

        <Feedback phase={phase} q={q} />

        {phase === 'revealed' && (
          <div style={{ textAlign: 'center', marginTop: 16 }}>
            <button className="btn btn--primary btn--lg" onClick={next}>
              {i < QUIZ.length - 1 ? <>Next Question <ArrowRight size={18} /></> : <>Finish Quiz <ArrowRight size={18} /></>}
            </button>
          </div>
        )}
      </div>
      <p className="notice" style={{ maxWidth: 520, margin: '14px auto 0' }}>Answered {answeredCount} of {QUIZ.length}. You can try each question once more before the answer is shown.</p>
    </div>
  );
}

function Feedback({ phase, q }: { phase: Phase; q: QuizQuestion }) {
  if (phase === 'retry') {
    return <div className="feedback no"><X size={20} /><span>{q.hintFeedback} Try once more!</span></div>;
  }
  if (phase === 'revealed') {
    // If they got here after being wrong twice we still show the encouraging success text of the answer.
    return <div className="feedback ok"><Check size={20} /><span>{q.successFeedback}</span></div>;
  }
  return null;
}

function OrderUI({ tray, bank, phase, answer, onAdd, onRemove, onCheck, onSpeak }: {
  tray: string[]; bank: string[]; phase: Phase; answer: string;
  onAdd: (w: string, i: number) => void; onRemove: (i: number) => void; onCheck: () => void; onSpeak: () => void;
}) {
  return (
    <div>
      <div className="order-tray" aria-label="Your sentence">
        {tray.length === 0 && <span style={{ color: 'var(--ink-soft)' }}>Tap the words below in order…</span>}
        {tray.map((w, idx) => (
          <button key={idx} className="word-btn in-tray" onClick={() => onRemove(idx)} disabled={phase === 'revealed'}>
            {w}
          </button>
        ))}
      </div>
      <div className="order-bank">
        {bank.map((w, idx) => (
          <button key={idx} className="word-btn" onClick={() => onAdd(w, idx)} disabled={phase === 'revealed'}>{w}</button>
        ))}
      </div>
      {phase !== 'revealed' ? (
        <div style={{ textAlign: 'center', marginTop: 4 }}>
          <button className="btn btn--soft" onClick={() => onRemove(tray.length - 1)} disabled={tray.length === 0}>
            <Delete size={16} /> Undo
          </button>{' '}
          <button className="btn btn--primary" onClick={onCheck} disabled={tray.length === 0}>Check</button>
        </div>
      ) : (
        <div style={{ textAlign: 'center', marginTop: 4 }}>
          <span className="starter" style={{ display: 'inline-block' }}>{answer}
            <button className="btn btn--icon" style={{ background: 'transparent', color: 'var(--ocean)', minHeight: 'auto', padding: 4, boxShadow: 'none' }}
              aria-label="Listen to the sentence" onClick={onSpeak}><Volume2 size={16} /></button>
          </span>
        </div>
      )}
    </div>
  );
}
