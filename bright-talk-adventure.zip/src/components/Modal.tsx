import { useEffect, useRef } from 'react';
import type { ReactNode } from 'react';

interface Props {
  title: string; children?: ReactNode;
  confirmLabel?: string; cancelLabel?: string;
  onConfirm?: () => void; onCancel: () => void;
  danger?: boolean;
}

export function Modal({ title, children, confirmLabel, cancelLabel = 'Cancel', onConfirm, onCancel, danger }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onCancel(); };
    document.addEventListener('keydown', onKey);
    ref.current?.querySelector<HTMLElement>('button')?.focus();
    return () => document.removeEventListener('keydown', onKey);
  }, [onCancel]);

  return (
    <div className="modal-backdrop" onClick={onCancel} role="presentation">
      <div className="modal" ref={ref} role="dialog" aria-modal="true" aria-label={title}
        onClick={(e) => e.stopPropagation()}>
        <h2>{title}</h2>
        {children}
        <div className="modal__actions">
          <button className="btn btn--ghost" onClick={onCancel}>{cancelLabel}</button>
          {onConfirm && (
            <button className={`btn ${danger ? 'btn--primary' : ''}`} onClick={onConfirm}>{confirmLabel}</button>
          )}
        </div>
      </div>
    </div>
  );
}
