import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Play, ListChecks, FileText, RotateCcw, Award } from 'lucide-react';
import { useApp } from '../store/AppContext';
import { WORLDS } from '../data/worlds';
import { QUESTIONS } from '../data/questions';
import { BadgeArt } from '../art/BadgeArt';
import { Brighty } from '../art/Brighty';
import { Modal } from '../components/Modal';

export function ProgressPage() {
  const { progress, resetProgress } = useApp();
  const nav = useNavigate();
  const [confirm, setConfirm] = useState(false);

  const totalMissions = QUESTIONS.length;
  const completed = progress.completedMissions.length;
  const worldsDone = WORLDS.filter((w) => w.questionIds.every((id) => progress.completedMissions.includes(id))).length;

  const checklistSummary = useMemo(() => {
    const vals = Object.values(progress.checklists);
    const totals = { tried: 0, fullSentence: 0, spokeClearly: 0, extraDetail: 0 };
    vals.forEach((c) => {
      if (c.tried) totals.tried++;
      if (c.fullSentence) totals.fullSentence++;
      if (c.spokeClearly) totals.spokeClearly++;
      if (c.extraDetail) totals.extraDetail++;
    });
    return { count: vals.length, totals };
  }, [progress.checklists]);

  const mostPracticed = useMemo(() => {
    const entries = Object.entries(progress.practiceCount) as [string, number][];
    const top = entries.sort((a, b) => b[1] - a[1])[0];
    if (!top || top[1] === 0) return '—';
    return WORLDS.find((w) => w.id === top[0])?.name ?? '—';
  }, [progress.practiceCount]);

  const encourage = completed === 0
    ? "Let's begin! Choose a world on your Learning Map and start your first mission."
    : completed >= totalMissions
      ? `Amazing, ${progress.studentName || 'friend'}! You completed all ${totalMissions} conversation missions. You are a Bright Talk star!`
      : `You completed ${completed} conversation mission${completed === 1 ? '' : 's'}. Your confidence is growing!`;

  const dateStr = progress.quizCompletedAt ? new Date(progress.quizCompletedAt).toLocaleDateString() : '—';

  return (
    <div className="container">
      <div className="page-head">
        <h1>Progress &amp; Results</h1>
        <p>A gentle summary of your speaking practice. Every learner grows at their own pace.</p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
        <Brighty mood={completed >= totalMissions ? 'cheer' : 'happy'} size={110} />
      </div>
      <div className="encourage">{encourage}</div>

      <div className="grid stat-grid" style={{ marginBottom: 20 }}>
        <div className="card stat"><div className="big">{completed}/{totalMissions}</div><div className="lbl">Missions completed</div></div>
        <div className="card stat"><div className="big">{worldsDone}/5</div><div className="lbl">Worlds completed</div></div>
        <div className="card stat"><div className="big">{progress.quizBestScore}/25</div><div className="lbl">Best quiz score</div></div>
        <div className="card stat"><div className="big" style={{ fontSize: '1.3rem' }}>{mostPracticed}</div><div className="lbl">Most practiced</div></div>
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <h3 style={{ marginBottom: 12 }}>Badges Earned</h3>
        <div className="badge-row">
          {WORLDS.map((w) => {
            const earned = progress.earnedBadges.includes(w.badge.id);
            return (
              <div className="badge-item" key={w.id}>
                <BadgeArt world={w.id} earned={earned} size={72} />
                <div className="t">{w.badge.title}</div>
                <div className="d">{earned ? w.badge.description : 'Not yet earned'}</div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <h3 style={{ marginBottom: 8 }}>Speaking Checklist Summary</h3>
        {checklistSummary.count === 0 ? (
          <p style={{ color: 'var(--ink-soft)' }}>Tick the speaking checklist in Learn &amp; Speak mode to see a summary here.</p>
        ) : (
          <ul style={{ paddingLeft: 20, margin: 0 }}>
            <li>Tried to answer: <strong>{checklistSummary.totals.tried}</strong> missions</li>
            <li>Used a full sentence: <strong>{checklistSummary.totals.fullSentence}</strong> missions</li>
            <li>Spoke clearly: <strong>{checklistSummary.totals.spokeClearly}</strong> missions</li>
            <li>Added one extra detail: <strong>{checklistSummary.totals.extraDetail}</strong> missions</li>
          </ul>
        )}
        <p style={{ color: 'var(--ink-soft)', fontSize: '.85rem', marginTop: 8 }}>Last quiz: {dateStr}</p>
      </div>

      <div className="cls-toolbar" style={{ justifyContent: 'center' }}>
        <button className="btn btn--primary" onClick={() => nav('/map')}><Play size={18} /> Continue Practicing</button>
        <button className="btn btn--soft" onClick={() => nav('/quiz')}><ListChecks size={18} /> Review Questions</button>
        <button className="btn btn--ghost" onClick={() => nav('/print?doc=certificate')}><Award size={18} /> Print Certificate</button>
        <button className="btn btn--ghost" onClick={() => nav('/print?doc=report')}><FileText size={18} /> Print Progress Report</button>
        <button className="btn btn--ghost" style={{ color: 'var(--coral)' }} onClick={() => setConfirm(true)}><RotateCcw size={18} /> Reset Progress</button>
      </div>

      {/* Printable progress report (screen-hidden, print-shown) */}
      <div className="print-only print-page" style={{ marginTop: 30 }}>
        <h2 style={{ textAlign: 'center' }}>Bright Talk Adventure — Progress Report</h2>
        <p><strong>Student:</strong> {progress.studentName || '________________'}</p>
        <p><strong>Missions completed:</strong> {completed} / {totalMissions}</p>
        <p><strong>Worlds completed:</strong> {worldsDone} / 5</p>
        <p><strong>Best quiz score:</strong> {progress.quizBestScore} / 25</p>
        <p><strong>Most practiced world:</strong> {mostPracticed}</p>
        <p><strong>Badges earned:</strong> {progress.earnedBadges.length} / 5</p>
        <div className="print-credit">Bright Talk Adventure · Created by Bright EngMath</div>
      </div>

      {confirm && (
        <Modal title="Reset all progress?" confirmLabel="Yes, reset" danger
          onCancel={() => setConfirm(false)}
          onConfirm={() => { resetProgress(); setConfirm(false); }}>
          <p>This clears completed missions, badges, quiz scores and checklists on this device. Class data in Classroom Mode is kept separately.</p>
        </Modal>
      )}
    </div>
  );
}
