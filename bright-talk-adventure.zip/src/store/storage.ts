import type { StudentProgress, TeacherSettings, SoundSettings, WorldId } from '../types';

const KEYS = {
  progress: 'bta.progress.v1',
  teacher: 'bta.teacher.v1',
  sound: 'bta.sound.v1',
} as const;

const PROGRESS_VERSION = 1;
const TEACHER_VERSION = 1;
const SOUND_VERSION = 1;

function emptyPractice(): Record<WorldId, number> {
  return { w1: 0, w2: 0, w3: 0, w4: 0, w5: 0 };
}

export function defaultProgress(): StudentProgress {
  return {
    version: PROGRESS_VERSION,
    studentName: '',
    completedMissions: [],
    supportLevel: 1,
    checklists: {},
    earnedBadges: [],
    quizBestScore: 0,
    quizLastScore: 0,
    quizIncorrect: [],
    quizCompletedAt: null,
    practiceCount: emptyPractice(),
    lastUpdated: new Date().toISOString(),
  };
}

export function defaultTeacher(): TeacherSettings {
  return {
    version: TEACHER_VERSION,
    students: [],
    showModelAnswer: false,
    showThaiHint: false,
    showVocabulary: true,
    classCompleted: [],
  };
}

export function defaultSound(): SoundSettings {
  return {
    version: SOUND_VERSION,
    voice: true,
    effects: true,
    celebration: true,
    muteAll: false,
    animations: true,
  };
}

/** Safe read: returns fallback on missing / corrupt / version-mismatch data. */
function safeRead<T extends { version: number }>(key: string, version: number, fallback: () => T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback();
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || parsed.version !== version) {
      // Old or unknown version: discard gracefully.
      return fallback();
    }
    // Merge over defaults so any newly-added fields are present.
    return { ...fallback(), ...parsed, version } as T;
  } catch {
    return fallback();
  }
}

function safeWrite(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full or unavailable (private mode) — fail silently */
  }
}

export const store = {
  loadProgress: () => {
    const p = safeRead(KEYS.progress, PROGRESS_VERSION, defaultProgress);
    if (!p.practiceCount) p.practiceCount = emptyPractice();
    if (!Array.isArray(p.completedMissions)) p.completedMissions = [];
    return p;
  },
  saveProgress: (p: StudentProgress) => safeWrite(KEYS.progress, { ...p, lastUpdated: new Date().toISOString() }),

  loadTeacher: () => safeRead(KEYS.teacher, TEACHER_VERSION, defaultTeacher),
  saveTeacher: (t: TeacherSettings) => safeWrite(KEYS.teacher, t),

  loadSound: () => safeRead(KEYS.sound, SOUND_VERSION, defaultSound),
  saveSound: (s: SoundSettings) => safeWrite(KEYS.sound, s),

  clearProgress: () => { try { localStorage.removeItem(KEYS.progress); } catch { /* ignore */ } },
  clearTeacher: () => { try { localStorage.removeItem(KEYS.teacher); } catch { /* ignore */ } },
};
