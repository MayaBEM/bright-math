import { Link } from 'react-router-dom';
import { Map, BookOpenText, LayoutGrid, Disc3, Presentation, ListChecks, Printer } from 'lucide-react';

const MODES = [
  { to: '/map', icon: Map, color: 'var(--w1)', title: 'Learning Map', text: 'Travel through 5 conversation worlds and earn badges.' },
  { to: '/learn', icon: BookOpenText, color: 'var(--w2)', title: 'Learn & Speak', text: 'Listen, practice and record your answer for each mission.' },
  { to: '/cards', icon: LayoutGrid, color: 'var(--w3)', title: 'Pick a Card', text: 'Flip a card to reveal a surprise question.' },
  { to: '/spin', icon: Disc3, color: 'var(--w4)', title: 'Spin & Speak', text: 'Spin the wheel and answer the question it lands on.' },
  { to: '/classroom', icon: Presentation, color: 'var(--w5)', title: 'Classroom Mode', text: 'Big-screen tools, timers and a random student picker.' },
  { to: '/quiz', icon: ListChecks, color: 'var(--ocean)', title: 'Review Quiz', text: '25 mixed questions with instant, friendly feedback.' },
  { to: '/print', icon: Printer, color: 'var(--coral)', title: 'Printables', text: 'Question cards, checklists and a certificate for A4.' },
];

export function ModeSelectPage() {
  return (
    <div className="container">
      <div className="page-head">
        <h1>Choose an Activity</h1>
        <p>Pick how you would like to practice today. You can switch at any time — your progress is always saved.</p>
      </div>
      <div className="grid mode-grid">
        {MODES.map((m) => (
          <Link className="card mode-card" to={m.to} key={m.to}>
            <span className="ic" style={{ background: m.color }}><m.icon size={26} /></span>
            <h3>{m.title}</h3>
            <p>{m.text}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
