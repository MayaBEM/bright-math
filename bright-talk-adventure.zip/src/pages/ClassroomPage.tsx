import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Maximize2, Minimize2, Shuffle, ChevronLeft, ChevronRight, Eye, EyeOff, Languages,
  BookA, Volume2, VolumeX, Sparkles, Timer, Pause, Play, RotateCcw, UserPlus, Dice5,
  Star, Trash2, CheckCircle2, X,
} from 'lucide-react';
import { useApp } from '../store/AppContext';
import { WORLDS, WORLDS_BY_ID, worldOfQuestion } from '../data/worlds';
import { QUESTIONS_BY_ID } from '../data/questions';
import { useSpeech } from '../hooks/useSpeech';
import { useSfx } from '../hooks/useSfx';
import { Modal } from '../components/Modal';

const ORDER = WORLDS.flatMap((w) => w.questionIds);
const TIMES = [15, 30, 45, 60];

export function ClassroomPage() {
  const nav = useNavigate();
  const { teacher, updateTeacher, addStudent, removeStudent, awardStar, markPicked, clearClassData, sound, updateSound } = useApp();
  const { speak } = useSpeech();
  const { play } = useSfx();

  const [idx, setIdx] = useState(0);
  const [fs, setFs] = useState(false);
  const [name, setName] = useState('');
  const [picked, setPicked] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [done, setDone] = useState<Set<number>>(new Set(teacher.classCompleted));

  // Timer
  const [timeLeft, setTimeLeft] = useState(0);
  const [running, setRunning] = useState(false);
  const tick = useRef<number | null>(null);
  useEffect(() => {
    if (running && timeLeft > 0) {
      tick.current = window.setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    } else if (timeLeft === 0) {
      setRunning(false);
    }
    return () => { if (tick.current) window.clearTimeout(tick.current); };
  }, [running, timeLeft]);

  const q = QUESTIONS_BY_ID[ORDER[idx]];
  const world = worldOfQuestion(q.id);

  const go = (n: number) => { setIdx((i) => (i + n + ORDER.length) % ORDER.length); setPicked(null); play('click'); };
  const random = () => { setIdx(Math.floor(Math.random() * ORDER.length)); setPicked(null); play('click'); };

  const pickStudent = () => {
    if (teacher.students.length === 0) return;
    play('spin');
    const pick = teacher.students[Math.floor(Math.random() * teacher.students.length)];
    setPicked(pick.name);
    markPicked(pick.id);
  };

  const startTimer = (secs: number) => { setTimeLeft(secs); setRunning(true); };
  const toggleDone = () => {
    const next = new Set(done);
    if (next.has(q.id)) next.delete(q.id); else { next.add(q.id); play('success'); }
    setDone(next);
    updateTeacher({ classCompleted: [...next] });
  };

  const toggleFs = async () => {
    try {
      if (!document.fullscreenElement) { await document.documentElement.requestFullscreen(); setFs(true); }
      else { await document.exitFullscreen(); setFs(false); }
    } catch { setFs((f) => !f); }
  };
  useEffect(() => {
    const h = () => setFs(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', h);
    return () => document.removeEventListener('fullscreenchange', h);
  }, []);

  const pickedStudent = teacher.students.find((s) => s.name === picked);

  return (
    <div className="container cls-shell" style={{ ['--wc' as string]: world.color }}>
      <button className="back-link no-print" onClick={() => nav('/modes')}><ChevronLeft size={18} /> Back to Activities</button>
      <div className="page-head no-print" style={{ marginBottom: 12 }}>
        <h1>Classroom Mode</h1>
        <p>Teacher tools for the big screen. Student names and stars are saved on this device only.</p>
      </div>

      <div className="cls-stage">
        <div style={{ display: 'flex', gap: 10, justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' }}>
          <span className="q-cat">{WORLDS_BY_ID[world.id].name} · Question {idx + 1} / {ORDER.length}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            {done.has(q.id) && <span className="chip" style={{ background: 'var(--mint-soft)' }}><CheckCircle2 size={15} /> Done</span>}
            <button className="btn btn--ghost btn--icon" aria-label="Fullscreen" onClick={toggleFs}>
              {fs ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>
          </div>
        </div>

        <h2 className="q-text" style={{ fontSize: 'clamp(1.8rem, 5vw, 3rem)', margin: '18px 0' }}>{q.question}</h2>

        {teacher.showVocabulary && (
          <div className="vocab">{q.vocabulary.map((v) => <span className="vchip" key={v}>{v}</span>)}</div>
        )}
        {teacher.showModelAnswer && (
          <div className="example-box" style={{ textAlign: 'left', maxWidth: 640, margin: '0 auto 12px' }}>
            <h4>Short answer</h4><p>{q.shortAnswer}</p>
            <h4>Extended answer</h4><p style={{ marginBottom: 0 }}>{q.extendedAnswer}</p>
          </div>
        )}
        {teacher.showThaiHint && <div className="hint-box" lang="th" style={{ maxWidth: 520, margin: '0 auto 12px' }}>{q.thaiHint}</div>}

        {picked && <div className="picked-banner anim-pop">⭐ {picked}, your turn!</div>}

        <div className="cls-toolbar no-print">
          <button className="btn btn--ghost" onClick={() => go(-1)}><ChevronLeft size={18} /> Previous</button>
          <button className="btn btn--soft" onClick={() => speak(q.question)}><Volume2 size={18} /> Read</button>
          <button className="btn btn--soft" onClick={random}><Shuffle size={18} /> Random</button>
          <button className="btn btn--mint" onClick={toggleDone}><CheckCircle2 size={18} /> {done.has(q.id) ? 'Unmark' : 'Mark Done'}</button>
          <button className="btn btn--ghost" onClick={() => go(1)}>Next <ChevronRight size={18} /></button>
        </div>

        <div className="cls-toolbar no-print" style={{ marginTop: 8 }}>
          <button className="btn btn--ghost" onClick={() => updateTeacher({ showModelAnswer: !teacher.showModelAnswer })}>
            {teacher.showModelAnswer ? <EyeOff size={16} /> : <Eye size={16} />} Model Answer
          </button>
          <button className="btn btn--ghost" onClick={() => updateTeacher({ showThaiHint: !teacher.showThaiHint })}>
            <Languages size={16} /> Thai Hint
          </button>
          <button className="btn btn--ghost" onClick={() => updateTeacher({ showVocabulary: !teacher.showVocabulary })}>
            <BookA size={16} /> Vocabulary
          </button>
          <button className="btn btn--ghost" onClick={() => updateSound({ muteAll: !sound.muteAll })}>
            {sound.muteAll ? <VolumeX size={16} /> : <Volume2 size={16} />} Sound {sound.muteAll ? 'Off' : 'On'}
          </button>
          <button className="btn btn--ghost" onClick={() => updateSound({ animations: !sound.animations })}>
            <Sparkles size={16} /> Animation {sound.animations ? 'On' : 'Off'}
          </button>
        </div>
      </div>

      <div className="cls-section no-print">
        {/* Timer */}
        <div className="card">
          <h3 style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Timer size={20} /> Timer</h3>
          <div className={`timer-big${timeLeft <= 5 && timeLeft > 0 ? ' low' : ''}`} style={{ textAlign: 'center' }}>
            {String(Math.floor(timeLeft / 60)).padStart(1, '0')}:{String(timeLeft % 60).padStart(2, '0')}
          </div>
          <div className="cls-toolbar" style={{ marginTop: 6 }}>
            {TIMES.map((t) => (
              <button key={t} className="btn btn--soft" onClick={() => startTimer(t)}>{t}s</button>
            ))}
          </div>
          <div className="cls-toolbar" style={{ marginTop: 8 }}>
            <button className="btn btn--ghost" onClick={() => setRunning((r) => !r)} disabled={timeLeft === 0}>
              {running ? <><Pause size={16} /> Pause</> : <><Play size={16} /> Resume</>}
            </button>
            <button className="btn btn--ghost" onClick={() => { setRunning(false); setTimeLeft(0); }}>
              <RotateCcw size={16} /> Reset
            </button>
          </div>
        </div>

        {/* Students */}
        <div className="card">
          <h3 style={{ display: 'flex', alignItems: 'center', gap: 8 }}><UserPlus size={20} /> Class</h3>
          <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
            <input value={name} onChange={(e) => setName(e.target.value)} maxLength={20}
              placeholder="Add a student name"
              onKeyDown={(e) => { if (e.key === 'Enter') { addStudent(name); setName(''); } }}
              style={{ flex: 1, padding: '10px 14px', borderRadius: 12, border: '2px solid var(--line)', fontFamily: 'var(--font-body)' }} />
            <button className="btn" onClick={() => { addStudent(name); setName(''); }}>Add</button>
          </div>
          <div className="cls-toolbar" style={{ justifyContent: 'flex-start', marginTop: 10 }}>
            <button className="btn btn--sun" onClick={pickStudent} disabled={teacher.students.length === 0}>
              <Dice5 size={16} /> Random Student
            </button>
            {pickedStudent && (
              <button className="btn btn--mint" onClick={() => awardStar(pickedStudent.id)}>
                <Star size={16} /> Award {pickedStudent.name} a Star
              </button>
            )}
          </div>
          <div className="student-list">
            {teacher.students.length === 0 && <p style={{ color: 'var(--ink-soft)' }}>No students yet. Add names to use the random picker and stars.</p>}
            {teacher.students.map((s) => (
              <span key={s.id} className={`student-pill${picked === s.name ? ' picked' : ''}`}>
                {s.name}
                {s.stars > 0 && <span className="stars">{'★'.repeat(Math.min(s.stars, 5))}{s.stars > 5 ? `+${s.stars - 5}` : ''}</span>}
                <button className="btn btn--icon" style={{ minWidth: 30, minHeight: 30, padding: 4, background: 'var(--sunshine)', color: 'var(--ocean-deep)' }}
                  aria-label={`Give ${s.name} a star`} onClick={() => awardStar(s.id)}><Star size={14} /></button>
                <button className="btn btn--icon" style={{ minWidth: 30, minHeight: 30, padding: 4, background: '#fff', color: 'var(--coral)', border: '1px solid var(--line)' }}
                  aria-label={`Remove ${s.name}`} onClick={() => removeStudent(s.id)}><X size={14} /></button>
              </span>
            ))}
          </div>
          {teacher.students.length > 0 && (
            <p style={{ color: 'var(--ink-soft)', fontSize: '.85rem', marginTop: 10 }}>
              Participation: {teacher.students.reduce((a, s) => a + s.timesPicked, 0)} turns · {teacher.students.reduce((a, s) => a + s.stars, 0)} stars given
            </p>
          )}
          <button className="btn btn--ghost" style={{ marginTop: 10, color: 'var(--coral)' }} onClick={() => setConfirmClear(true)}>
            <Trash2 size={16} /> Clear Class Data
          </button>
        </div>
      </div>

      {confirmClear && (
        <Modal title="Clear all class data?" confirmLabel="Yes, clear it" danger
          onCancel={() => setConfirmClear(false)}
          onConfirm={() => { clearClassData(); setDone(new Set()); setPicked(null); setConfirmClear(false); }}>
          <p>This will remove all student names, stars and participation counts on this device. This cannot be undone.</p>
        </Modal>
      )}
    </div>
  );
}
