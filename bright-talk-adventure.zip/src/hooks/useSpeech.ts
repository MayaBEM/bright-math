import { useCallback, useEffect, useState } from 'react';
import { useApp } from '../store/AppContext';

/** Text-to-speech using the Web Speech API (SpeechSynthesis). */
export function useSpeech() {
  const { sound } = useApp();
  const [supported, setSupported] = useState(false);

  useEffect(() => {
    setSupported(typeof window !== 'undefined' && 'speechSynthesis' in window);
  }, []);

  const pickVoice = useCallback((): SpeechSynthesisVoice | null => {
    if (!('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();
    // Prefer an English voice; fall back to the first available.
    const en = voices.find((v) => /en[-_]/i.test(v.lang)) || voices.find((v) => v.lang.startsWith('en'));
    return en || voices[0] || null;
  }, []);

  const speak = useCallback((text: string, opts?: { slow?: boolean }) => {
    if (!('speechSynthesis' in window)) return;
    if (sound.muteAll || !sound.voice) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US';
    u.rate = opts?.slow ? 0.6 : 0.95;
    u.pitch = 1.05;
    const v = pickVoice();
    if (v) u.voice = v;
    window.speechSynthesis.speak(u);
  }, [sound.muteAll, sound.voice, pickVoice]);

  const stop = useCallback(() => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  }, []);

  useEffect(() => () => stop(), [stop]);

  return { speak, stop, supported };
}
