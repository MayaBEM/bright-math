export type WorldId = 'w1' | 'w2' | 'w3' | 'w4' | 'w5';
export type Difficulty = 'Starter' | 'Growing' | 'Confident';
export type SupportLevel = 1 | 2 | 3;

export interface ConversationQuestion {
  id: number;
  worldId: WorldId;
  category: string;
  question: string;
  difficulty: Difficulty;
  vocabulary: string[];
  sentenceStarter: string;
  shortAnswer: string;
  extendedAnswer: string;
  followUpQuestion: string;
  thaiHint: string;
  teacherTip: string;
}

export interface World {
  id: WorldId;
  name: string;
  subtitle: string;
  color: string;
  colorSoft: string;
  badge: Badge;
  questionIds: number[];
}

export interface Badge {
  id: string;
  worldId: WorldId;
  title: string;
  description: string;
}

export type QuizType =
  | 'choose'        // Choose the best answer
  | 'match'         // Match a question with an answer
  | 'complete'      // Complete the sentence
  | 'order'         // Put the words in order
  | 'listen'        // Listen and choose
  | 'followup';     // Choose the suitable follow-up question

export interface QuizQuestion {
  id: number;
  type: QuizType;
  worldId: WorldId;
  prompt: string;         // the main instruction / question text
  listenText?: string;    // for 'listen' type: spoken sentence
  words?: string[];       // for 'order' type: shuffled words to arrange
  answer: string;         // correct answer string
  choices: string[];      // options (for order type: the target ordered sentence tokens joined)
  correctIndex: number;   // index into choices of the correct one
  successFeedback: string;
  hintFeedback: string;   // shown after a wrong attempt
}

export interface SpeakingChecklist {
  tried: boolean;
  fullSentence: boolean;
  spokeClearly: boolean;
  extraDetail: boolean;
}

export interface StudentProgress {
  version: number;
  studentName: string;
  completedMissions: number[];          // question ids marked complete
  supportLevel: SupportLevel;
  checklists: Record<number, SpeakingChecklist>;
  earnedBadges: string[];               // badge ids
  quizBestScore: number;                // 0..25
  quizLastScore: number;
  quizIncorrect: number[];              // quiz question ids answered wrong
  quizCompletedAt: string | null;
  practiceCount: Record<WorldId, number>;
  lastUpdated: string;
}

export interface ClassroomStudent {
  id: string;
  name: string;
  stars: number;
  timesPicked: number;
}

export interface TeacherSettings {
  version: number;
  students: ClassroomStudent[];
  showModelAnswer: boolean;
  showThaiHint: boolean;
  showVocabulary: boolean;
  classCompleted: number[];   // question ids marked done in classroom mode
}

export interface SoundSettings {
  version: number;
  voice: boolean;
  effects: boolean;
  celebration: boolean;
  muteAll: boolean;
  animations: boolean;
}
