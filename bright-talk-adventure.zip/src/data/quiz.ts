import type { QuizQuestion } from '../types';

// Helper to keep the shape consistent for "order" questions.
const order = (
  id: number, worldId: QuizQuestion['worldId'], answer: string, words: string[], hint: string,
): QuizQuestion => ({
  id, type: 'order', worldId,
  prompt: 'Put the words in order to make a sentence.',
  words, answer, choices: [answer], correctIndex: 0,
  successFeedback: 'Perfect! You put the words in the right order.',
  hintFeedback: hint,
});

export const QUIZ: QuizQuestion[] = [
  // ---------- Choose the best answer ----------
  {
    id: 1, type: 'choose', worldId: 'w2',
    prompt: 'What is your favorite fruit?',
    choices: ['My favorite fruit is mango.', 'I am seven years old.', 'It is sunny today.'],
    answer: 'My favorite fruit is mango.', correctIndex: 0,
    successFeedback: 'Great answer! You matched the question with the correct response.',
    hintFeedback: 'Almost there! The question asks about fruit, so choose an answer that names a fruit.',
  },
  {
    id: 2, type: 'choose', worldId: 'w1',
    prompt: 'How old are you?',
    choices: ['I live in Bangkok.', 'I am six years old.', 'My name is Mia.'],
    answer: 'I am six years old.', correctIndex: 1,
    successFeedback: 'Great answer! That tells us your age.',
    hintFeedback: 'Almost there! The question asks about age, so choose an answer with a number of years.',
  },
  {
    id: 3, type: 'choose', worldId: 'w2',
    prompt: 'What is your favorite color?',
    choices: ['My favorite color is blue.', 'I have a cat.', 'It is Monday.'],
    answer: 'My favorite color is blue.', correctIndex: 0,
    successFeedback: 'Great answer! You named a color.',
    hintFeedback: 'This question asks about a color. Look for the answer that names a color.',
  },
  {
    id: 4, type: 'choose', worldId: 'w1',
    prompt: 'Where do you live?',
    choices: ['I like ice cream.', 'I live in Chiang Mai.', 'I am fine, thank you.'],
    answer: 'I live in Chiang Mai.', correctIndex: 1,
    successFeedback: 'Great answer! That tells us the place where you live.',
    hintFeedback: 'This question asks about a place. Choose the answer that names where someone lives.',
  },
  {
    id: 5, type: 'choose', worldId: 'w4',
    prompt: 'What is the weather like today?',
    choices: ['Today, the weather is sunny.', 'My favorite toy is a ball.', 'I am happy.'],
    answer: 'Today, the weather is sunny.', correctIndex: 0,
    successFeedback: 'Great answer! That describes the weather.',
    hintFeedback: 'This question asks about the weather. Choose the answer that describes the day.',
  },

  // ---------- Match a question with an answer ----------
  {
    id: 6, type: 'match', worldId: 'w3',
    prompt: 'Answer: "In my family, there are my mom, my dad, and me." Which question matches?',
    choices: ['Who is in your family?', 'How are you today?', 'What is your favorite song?'],
    answer: 'Who is in your family?', correctIndex: 0,
    successFeedback: 'Great match! The answer talks about family members.',
    hintFeedback: 'Look at the answer. It names family members, so find the question about family.',
  },
  {
    id: 7, type: 'match', worldId: 'w5',
    prompt: 'Answer: "When I grow up, I want to be a doctor." Which question matches?',
    choices: ['What do you want to be when you grow up?', 'What is your favorite fruit?', 'Where do you live?'],
    answer: 'What do you want to be when you grow up?', correctIndex: 0,
    successFeedback: 'Great match! The answer talks about a future job.',
    hintFeedback: 'The answer talks about a future job. Find the question about growing up.',
  },
  {
    id: 8, type: 'match', worldId: 'w2',
    prompt: 'Answer: "My favorite animal is a cat." Which question matches?',
    choices: ['What is your favorite animal?', 'How old are you?', 'What did you learn today?'],
    answer: 'What is your favorite animal?', correctIndex: 0,
    successFeedback: 'Great match! The answer names an animal.',
    hintFeedback: 'The answer names an animal. Find the matching question about animals.',
  },
  {
    id: 9, type: 'match', worldId: 'w4',
    prompt: 'Answer: "I feel happy when I play with my friends." Which question matches?',
    choices: ['What makes you happy?', 'What is the weather like today?', 'What is your name?'],
    answer: 'What makes you happy?', correctIndex: 0,
    successFeedback: 'Great match! The answer talks about feeling happy.',
    hintFeedback: 'The answer talks about feeling happy. Find the question about being happy.',
  },

  // ---------- Complete the sentence ----------
  {
    id: 10, type: 'complete', worldId: 'w1',
    prompt: 'Complete the sentence:  My name ___ Lily.',
    choices: ['is', 'are', 'am'], answer: 'is', correctIndex: 0,
    successFeedback: 'Great! "My name is Lily" is correct.',
    hintFeedback: "We use 'is' with 'My name'. Try: My name is Lily.",
  },
  {
    id: 11, type: 'complete', worldId: 'w1',
    prompt: 'Complete the sentence:  I ___ seven years old.',
    choices: ['am', 'is', 'are'], answer: 'am', correctIndex: 0,
    successFeedback: 'Great! "I am seven years old" is correct.',
    hintFeedback: "We say 'I am' when we talk about ourselves.",
  },
  {
    id: 12, type: 'complete', worldId: 'w2',
    prompt: 'Complete the sentence:  My favorite fruit is ___.',
    choices: ['mango', 'blue', 'happy'], answer: 'mango', correctIndex: 0,
    successFeedback: 'Great! A mango is a fruit, so the sentence makes sense.',
    hintFeedback: 'A fruit belongs in the blank. Mango is a fruit.',
  },
  {
    id: 13, type: 'complete', worldId: 'w4',
    prompt: 'Complete the sentence:  I feel happy ___ I play with my friends.',
    choices: ['when', 'what', 'who'], answer: 'when', correctIndex: 0,
    successFeedback: "Great! We use 'when' to say the time something happens.",
    hintFeedback: "We use 'when' to say the time something happens.",
  },

  // ---------- Put the words in order ----------
  order(14, 'w2', 'My favorite color is blue.', ['favorite', 'blue', 'My', 'is', 'color'],
    "Start with 'My' and end with the color. Try: My favorite color is blue."),
  order(15, 'w1', 'I live in Bangkok.', ['in', 'I', 'Bangkok', 'live'],
    "Start with 'I'. Try: I live in Bangkok."),
  order(16, 'w2', 'I like to eat rice.', ['eat', 'I', 'to', 'rice', 'like'],
    "Start with 'I like'. Try: I like to eat rice."),
  order(17, 'w2', 'My favorite animal is a cat.', ['a', 'favorite', 'My', 'cat', 'animal', 'is'],
    "Start with 'My favorite animal'. Try: My favorite animal is a cat."),

  // ---------- Listen and choose ----------
  {
    id: 18, type: 'listen', worldId: 'w2',
    prompt: 'Listen and choose the sentence you hear.',
    listenText: 'My favorite fruit is mango.',
    choices: ['My favorite fruit is mango.', 'My favorite fruit is apple.', 'My favorite toy is a car.'],
    answer: 'My favorite fruit is mango.', correctIndex: 0,
    successFeedback: 'Great listening! That is the sentence you heard.',
    hintFeedback: 'Press Listen again and choose the exact sentence you hear.',
  },
  {
    id: 19, type: 'listen', worldId: 'w1',
    prompt: 'Listen and choose the sentence you hear.',
    listenText: 'I am six years old.',
    choices: ['I am six years old.', 'I am seven years old.', 'I am fine, thank you.'],
    answer: 'I am six years old.', correctIndex: 0,
    successFeedback: 'Great listening! You heard the number six.',
    hintFeedback: 'Press Listen again and listen carefully to the number.',
  },
  {
    id: 20, type: 'listen', worldId: 'w4',
    prompt: 'Listen and choose the sentence you hear.',
    listenText: 'Today, the weather is sunny.',
    choices: ['Today, the weather is rainy.', 'Today, the weather is sunny.', 'Today, the weather is cold.'],
    answer: 'Today, the weather is sunny.', correctIndex: 1,
    successFeedback: 'Great listening! The weather word was "sunny".',
    hintFeedback: 'Press Listen again and listen for the weather word.',
  },
  {
    id: 21, type: 'listen', worldId: 'w1',
    prompt: 'Listen and choose the sentence you hear.',
    listenText: 'I live in Bangkok.',
    choices: ['I live in Bangkok.', 'I like Bangkok food.', 'I live in a big house.'],
    answer: 'I live in Bangkok.', correctIndex: 0,
    successFeedback: 'Great listening! That is the sentence you heard.',
    hintFeedback: 'Press Listen again and choose the exact sentence you hear.',
  },

  // ---------- Choose the suitable follow-up question ----------
  {
    id: 22, type: 'followup', worldId: 'w1',
    prompt: 'A friend says: "My name is Mia." Choose the best follow-up question.',
    choices: ['How do you spell your name?', 'What is the weather like?', 'How old is your cat?'],
    answer: 'How do you spell your name?', correctIndex: 0,
    successFeedback: 'Great! A good follow-up keeps talking about the same topic.',
    hintFeedback: 'A good follow-up stays on the same topic. Your friend just told you their name.',
  },
  {
    id: 23, type: 'followup', worldId: 'w3',
    prompt: 'A friend says: "I have a little brother." Choose the best follow-up question.',
    choices: ['Do you have any sisters too?', 'What is your favorite color?', 'Where is your school?'],
    answer: 'Do you have any sisters too?', correctIndex: 0,
    successFeedback: 'Great! You kept talking about family.',
    hintFeedback: 'A good follow-up asks more about the same idea — here, their family.',
  },
  {
    id: 24, type: 'followup', worldId: 'w2',
    prompt: 'A friend says: "My favorite animal is a cat." Choose the best follow-up question.',
    choices: ['Do you have a pet at home?', 'What is your name?', 'Is it raining?'],
    answer: 'Do you have a pet at home?', correctIndex: 0,
    successFeedback: 'Great! You kept talking about animals and pets.',
    hintFeedback: 'A good follow-up keeps talking about animals or pets.',
  },
  {
    id: 25, type: 'followup', worldId: 'w5',
    prompt: 'A friend says: "When I grow up, I want to be a teacher." Choose the best follow-up question.',
    choices: ['Why do you want to be a teacher?', 'What is your favorite fruit?', 'How old are you?'],
    answer: 'Why do you want to be a teacher?', correctIndex: 0,
    successFeedback: 'Great! You asked more about their dream job.',
    hintFeedback: 'A good follow-up asks more about their dream job.',
  },
];

export const QUIZ_TYPE_LABEL: Record<QuizQuestion['type'], string> = {
  choose: 'Choose the best answer',
  match: 'Match the question',
  complete: 'Complete the sentence',
  order: 'Put the words in order',
  listen: 'Listen and choose',
  followup: 'Choose the follow-up',
};
