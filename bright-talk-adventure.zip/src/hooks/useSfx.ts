import { useCallback, useRef } from 'react';
import { useApp } from '../store/AppContext';

type Kind = 'click' | 'success' | 'spin' | 'celebrate' | 'flip';

/** Lightweight sound effects generated with the Web Audio API (no asset files). */
export function useSfx() {
  const { sound } = useApp();
  const ctxRef = useRef<AudioContext | null>(null);

  const ctx = useCallback((): AudioContext | null => {
    if (typeof window === 'undefined') return null;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    if (!ctxRef.current) ctxRef.current = new AC();
    return ctxRef.current;
  }, []);

  const tone = useCallback((freq: number, dur: number, when: number, type: OscillatorType = 'sine', gain = 0.06) => {
    const ac = ctx();
    if (!ac) return;
    const osc = ac.createOscillator();
    const g = ac.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.value = gain;
    osc.connect(g); g.connect(ac.destination);
    const t = ac.currentTime + when;
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.start(t); osc.stop(t + dur);
  }, [ctx]);

  const play = useCallback((kind: Kind) => {
    if (sound.muteAll || !sound.effects) return;
    if (kind === 'celebrate' && !sound.celebration) return;
    switch (kind) {
      case 'click': tone(520, 0.08, 0, 'triangle', 0.04); break;
      case 'flip': tone(360, 0.09, 0, 'sine', 0.05); tone(560, 0.09, 0.05, 'sine', 0.04); break;
      case 'success': tone(660, 0.12, 0, 'sine'); tone(880, 0.16, 0.1, 'sine'); break;
      case 'spin': tone(300, 0.5, 0, 'sawtooth', 0.02); break;
      case 'celebrate':
        [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.22, i * 0.12, 'sine', 0.06));
        break;
    }
  }, [sound, tone]);

  return { play };
}
