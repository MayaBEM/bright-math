import { useApp } from '../store/AppContext';

/** Short, gentle confetti burst. Respects reduced-motion / animation setting. */
export function Confetti({ show }: { show: boolean }) {
  const { sound } = useApp();
  if (!show || !sound.animations) return null;
  const colors = ['var(--sky)', 'var(--coral)', 'var(--mint)', 'var(--sunshine)', 'var(--purple)'];
  const pieces = Array.from({ length: 28 });
  return (
    <div aria-hidden="true" style={{
      position: 'fixed', inset: 0, pointerEvents: 'none', overflow: 'hidden', zIndex: 60,
    }}>
      {pieces.map((_, i) => {
        const left = Math.random() * 100;
        const delay = Math.random() * 0.4;
        const dur = 1.6 + Math.random() * 1.2;
        const size = 8 + Math.random() * 8;
        return (
          <span key={i} style={{
            position: 'absolute', top: '-20px', left: `${left}%`,
            width: size, height: size * 0.6,
            background: colors[i % colors.length], borderRadius: 2,
            transform: `rotate(${Math.random() * 360}deg)`,
            animation: `confettiFall ${dur}s ${delay}s ease-in forwards`,
          }} />
        );
      })}
    </div>
  );
}
