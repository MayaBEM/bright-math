import { useNavigate } from 'react-router-dom';
import { Play, RotateCcw, CheckCircle2 } from 'lucide-react';
import { useApp } from '../store/AppContext';
import { WORLDS } from '../data/worlds';
import { WorldArt } from '../art/WorldArt';
import { BadgeArt } from '../art/BadgeArt';

export function LearningMapPage() {
  const { progress } = useApp();
  const nav = useNavigate();
  const done = new Set(progress.completedMissions);

  return (
    <div className="container">
      <div className="page-head">
        <h1>Your Learning Map</h1>
        <p>Five conversation worlds, five missions each. Start any world you like — there is no locked order.</p>
      </div>

      <div className="map-list">
        {WORLDS.map((w) => {
          const count = w.questionIds.filter((id) => done.has(id)).length;
          const pct = Math.round((count / w.questionIds.length) * 100);
          const started = count > 0;
          const complete = count === w.questionIds.length;
          const earned = progress.earnedBadges.includes(w.badge.id);
          return (
            <div className="card world-card" key={w.id} style={{ ['--wc' as string]: w.color }}>
              <div className="world-card__art"><WorldArt world={w.id} size={92} /></div>
              <div>
                <h3>{w.name}</h3>
                <div className="sub">{w.subtitle}</div>
                <div className="progress" aria-hidden="true"><span style={{ width: `${pct}%` }} /></div>
                <div className="meta">
                  <span>{count} / {w.questionIds.length} missions</span>
                  {complete && <span style={{ color: 'var(--mint)', display: 'inline-flex', alignItems: 'center', gap: 4 }}><CheckCircle2 size={16} /> World complete</span>}
                </div>
              </div>
              <div className="world-card__side">
                <BadgeArt world={w.id} earned={earned} size={64} />
                <button className="btn" style={{ background: w.color }}
                  onClick={() => nav(`/learn/${w.questionIds[Math.min(count, w.questionIds.length - 1)]}`)}>
                  {started ? (complete ? <><RotateCcw size={16} /> Review</> : <><Play size={16} /> Continue</>) : <><Play size={16} /> Start</>}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
