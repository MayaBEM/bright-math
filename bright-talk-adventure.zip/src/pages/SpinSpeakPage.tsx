import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Disc3, Volume2, CheckCircle2, RotateCcw, ChevronLeft, Triangle } from 'lucide-react';
import { WORLDS, WORLDS_BY_ID, worldOfQuestion } from '../data/worlds';
import { QUESTIONS_BY_ID } from '../data/questions';
import type { WorldId } from '../types';
import { useSpeech } from '../hooks/useSpeech';
import { useSfx } from '../hooks/useSfx';

const ALL = WORLDS.flatMap((w) => w.questionIds);
const WORLD_HEX: Record<WorldId, string> = { w1: '#4aa3df', w2: '#f2795f', w3: '#6fd0a8', w4: '#8c6ad4', w5: '#eaa93c' };

export function SpinSpeakPage() {
  const nav = useNavigate();
  const { speak } = useSpeech();
  const { play } = useSfx();
  const [filter, setFilter] = useState<WorldId | 'all'>('all');
  const [removeDone, setRemoveDone] = useState(true);
  const [answered, setAnswered] = useState<Set<number>>(new Set());
  const [angle, setAngle] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const wheelRef = useRef<HTMLDivElement>(null);

  const pool = useMemo(() => {
    let ids = filter === 'all' ? ALL : ALL.filter((id) => worldOfQuestion(id).id === filter);
    if (removeDone) ids = ids.filter((id) => !answered.has(id));
    return ids;
  }, [filter, removeDone, answered]);

  const seg = pool.length > 0 ? 360 / pool.length : 360;

  const spin = () => {
    if (spinning || pool.length === 0) return;
    play('spin');
    setResult(null);
    const target = Math.floor(Math.random() * pool.length);
    // Land the chosen segment's centre under the top pointer.
    const spins = 4 + Math.floor(Math.random() * 3);
    const centre = target * seg + seg / 2;
    const final = spins * 360 + (360 - centre);
    setSpinning(true);
    setAngle((prev) => prev - (prev % 360) + final);
    window.setTimeout(() => {
      setSpinning(false);
      setResult(pool[target]);
    }, 4100);
  };

  const markDone = () => {
    if (result == null) return;
    play('success');
    setAnswered((prev) => new Set(prev).add(result));
    setResult(null);
  };

  const q = result != null ? QUESTIONS_BY_ID[result] : null;
  const rWorld = result != null ? worldOfQuestion(result) : null;

  // Build conic-gradient background from world colors so the wheel uses the design system palette only.
  const bg = pool.length
    ? `conic-gradient(${pool.map((id, i) => {
        const col = WORLD_HEX[worldOfQuestion(id).id];
        const shade = i % 2 === 0 ? col : `${col}cc`;
        return `${shade} ${i * seg}deg ${(i + 1) * seg}deg`;
      }).join(', ')})`
    : '#e7dfd0';

  return (
    <div className="container">
      <button className="back-link" onClick={() => nav('/modes')}><ChevronLeft size={18} /> Back to Activities</button>
      <div className="page-head">
        <h1>Spin &amp; Speak</h1>
        <p>Spin the wheel and answer the question it lands on. Perfect for warm-ups and turn-taking.</p>
      </div>

      <div className="filter-row no-print" role="group" aria-label="Filter by world">
        <button className={filter === 'all' ? 'on' : ''} style={filter === 'all' ? { background: 'var(--ocean)' } : undefined}
          onClick={() => { setFilter('all'); setResult(null); }}>All Worlds</button>
        {WORLDS.map((w) => (
          <button key={w.id} className={filter === w.id ? 'on' : ''}
            style={filter === w.id ? { background: w.color } : undefined}
            onClick={() => { setFilter(w.id); setResult(null); }}>{w.name}</button>
        ))}
      </div>

      <div className="card-toolbar no-print" style={{ marginBottom: 18 }}>
        <label className="student-pill" style={{ cursor: 'pointer', paddingRight: 14 }}>
          <input type="checkbox" checked={removeDone} onChange={(e) => setRemoveDone(e.target.checked)} />
          Remove answered questions
        </label>
        <span className="chip">{pool.length} left · {answered.size} answered</span>
        {answered.size > 0 && (
          <button className="btn btn--ghost" onClick={() => setAnswered(new Set())}><RotateCcw size={16} /> Reset</button>
        )}
      </div>

      <div className="spin-stage">
        <div className="wheel-wrap">
          <Triangle className="wheel-pointer" size={34} fill="currentColor" style={{ transform: 'translateX(-50%) rotate(180deg)' }} />
          <div className="wheel" ref={wheelRef}
            style={{ background: bg, transform: `rotate(${angle}deg)`, transition: spinning ? undefined : 'none' }}
            role="img" aria-label={`Wheel with ${pool.length} questions`} />
          <div className="wheel-hub"><Disc3 size={26} /></div>
        </div>

        {pool.length === 0 ? (
          <div className="spin-result" style={{ ['--wc' as string]: 'var(--mint)' }}>
            <h3>All done in this selection! 🎉</h3>
            <p>You have answered every question here. Reset or choose another world to keep going.</p>
            <button className="btn btn--mint" onClick={() => setAnswered(new Set())}><RotateCcw size={16} /> Reset questions</button>
          </div>
        ) : (
          <button className="btn btn--primary btn--lg" onClick={spin} disabled={spinning}>
            <Disc3 size={20} /> {spinning ? 'Spinning…' : result ? 'Spin Again' : 'Spin the Wheel'}
          </button>
        )}

        {q && rWorld && (
          <div className="spin-result anim-pop" style={{ ['--wc' as string]: rWorld.color }}>
            <div className="q-cat" style={{ color: rWorld.color }}>{WORLDS_BY_ID[rWorld.id].name} · #{q.id}</div>
            <h2 className="q-text" style={{ margin: '6px 0 12px' }}>{q.question}</h2>
            <div className="starter" style={{ margin: '0 auto 14px' }}>{q.sentenceStarter}</div>
            <div className="audio-row" style={{ marginBottom: 0 }}>
              <button className="btn btn--soft" onClick={() => speak(q.question)}><Volume2 size={18} /> Listen</button>
              <button className="btn btn--mint" onClick={markDone}><CheckCircle2 size={18} /> Mark as Completed</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
