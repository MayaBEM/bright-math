import { useCallback, useEffect, useRef, useState } from 'react';

type RecState = 'idle' | 'recording' | 'recorded' | 'denied' | 'unsupported';

/** Microphone recording using the MediaRecorder API. Audio never leaves the browser. */
export function useRecorder() {
  const [state, setState] = useState<RecState>('idle');
  const [url, setUrl] = useState<string | null>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    const ok = typeof navigator !== 'undefined' && !!navigator.mediaDevices
      && typeof window !== 'undefined' && 'MediaRecorder' in window;
    if (!ok) setState('unsupported');
  }, []);

  const cleanupStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  const start = useCallback(async () => {
    if (state === 'unsupported') return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mr.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mr.mimeType || 'audio/webm' });
        setUrl((prev) => { if (prev) URL.revokeObjectURL(prev); return URL.createObjectURL(blob); });
        setState('recorded');
        cleanupStream();
      };
      mediaRef.current = mr;
      mr.start();
      setState('recording');
    } catch {
      setState('denied');
      cleanupStream();
    }
  }, [state, cleanupStream]);

  const stop = useCallback(() => {
    if (mediaRef.current && mediaRef.current.state !== 'inactive') mediaRef.current.stop();
  }, []);

  const reset = useCallback(() => {
    setUrl((prev) => { if (prev) URL.revokeObjectURL(prev); return null; });
    setState((s) => (s === 'unsupported' || s === 'denied' ? s : 'idle'));
  }, []);

  useEffect(() => () => {
    cleanupStream();
    setUrl((prev) => { if (prev) URL.revokeObjectURL(prev); return null; });
  }, [cleanupStream]);

  return { state, url, start, stop, reset };
}
