import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Printer } from 'lucide-react';
import { useApp } from '../store/AppContext';
import { WORLDS } from '../data/worlds';
import { QUESTIONS } from '../data/questions';

type Doc = 'cards' | 'checklist' | 'observation' | 'pair' | 'favorites' | 'certificate' | 'report';

const DOCS: { id: Doc; label: string }[] = [
  { id: 'cards', label: 'Question Cards' },
  { id: 'checklist', label: 'Speaking Checklist' },
  { id: 'observation', label: 'Observation Sheet' },
  { id: 'pair', label: 'Pair Work' },
  { id: 'favorites', label: 'Favorite Answers' },
  { id: 'certificate', label: 'Certificate' },
  { id: 'report', label: 'Progress Report' },
];

const Credit = () => <div className="print-credit">Bright Talk Adventure · 25 Daily Conversation Missions · Created by Bright EngMath</div>;

export function PrintPage() {
  const [params] = useSearchParams();
  const initial = (params.get('doc') as Doc) || 'cards';
  const [doc, setDoc] = useState<Doc>(DOCS.some((d) => d.id === initial) ? initial : 'cards');
  const { progress } = useApp();

  return (
    <div className="container print-preview">
      <div className="page-head no-print">
        <h1>Printable Materials</h1>
        <p>Choose a document, then press Print and select A4. Buttons and menus are hidden automatically when printing.</p>
      </div>

      <div className="print-controls no-print">
        {DOCS.map((d) => (
          <button key={d.id} className={`btn ${doc === d.id ? 'btn--primary' : 'btn--ghost'}`} onClick={() => setDoc(d.id)}>
            {d.label}
          </button>
        ))}
      </div>
      <div className="print-controls no-print" style={{ marginBottom: 24 }}>
        <button className="btn btn--lg" onClick={() => window.print()}><Printer size={20} /> Print this document</button>
      </div>

      {doc === 'cards' && (
        <div className="print-page">
          <h2 style={{ textAlign: 'center', marginBottom: 16 }}>Conversation Question Cards</h2>
          <div className="print-grid">
            {QUESTIONS.map((q) => (
              <div key={q.id} className="qcard-print">
                <span className="num">#{q.id} · {q.category}</span>
                <h3>{q.question}</h3>
                <p style={{ margin: '4px 0', color: '#333' }}><em>Starter:</em> {q.sentenceStarter}</p>
                <p style={{ margin: '4px 0', color: '#333' }}><em>Words:</em> {q.vocabulary.join(', ')}</p>
                <p style={{ margin: '4px 0', color: '#666', fontSize: '.85em' }} lang="th">{q.thaiHint}</p>
              </div>
            ))}
          </div>
          <Credit />
        </div>
      )}

      {doc === 'checklist' && (
        <div className="print-page">
          <h2 style={{ textAlign: 'center' }}>Student Speaking Checklist</h2>
          <p>Name: ______________________________   Date: ______________</p>
          <p style={{ color: '#555' }}>Tick a box each time you can say YES for a mission.</p>
          <table className="obs-table">
            <thead><tr><th style={{ width: '40%' }}>Question</th><th>I tried</th><th>Full sentence</th><th>Spoke clearly</th><th>Extra detail</th></tr></thead>
            <tbody>
              {QUESTIONS.slice(0, 13).map((q) => (
                <tr key={q.id}><td>#{q.id} {q.question}</td><td></td><td></td><td></td><td></td></tr>
              ))}
            </tbody>
          </table>
          <Credit />
        </div>
      )}

      {doc === 'observation' && (
        <div className="print-page">
          <h2 style={{ textAlign: 'center' }}>Teacher Observation Sheet</h2>
          <p>Teacher: __________________  Class: __________  Date: __________</p>
          <table className="obs-table">
            <thead><tr><th style={{ width: '26%' }}>Student</th><th>Question(s) practised</th><th>Fluency (1–5)</th><th>Notes</th></tr></thead>
            <tbody>
              {Array.from({ length: 12 }).map((_, i) => (
                <tr key={i}><td style={{ height: 30 }}></td><td></td><td></td><td></td></tr>
              ))}
            </tbody>
          </table>
          <p style={{ marginTop: 10, color: '#555' }}>Fluency guide: 1 single words · 3 short sentence · 5 full sentence with a detail.</p>
          <Credit />
        </div>
      )}

      {doc === 'pair' && (
        <div className="print-page">
          <h2 style={{ textAlign: 'center' }}>Pair Work Activity</h2>
          <p><strong>How to play:</strong> Work with a partner. Partner A asks a question, Partner B answers in a full sentence, then swap. Tick the box when you both have a turn.</p>
          <div className="print-grid">
            {WORLDS.map((w) => (
              <div key={w.id} className="qcard-print pair-block">
                <h3>{w.name}</h3>
                {w.questionIds.map((id) => {
                  const q = QUESTIONS.find((x) => x.id === id)!;
                  return <p key={id} className="chk-line"><span className="chk-box" /> {q.question}</p>;
                })}
              </div>
            ))}
          </div>
          <Credit />
        </div>
      )}

      {doc === 'favorites' && (
        <div className="print-page">
          <h2 style={{ textAlign: 'center' }}>My Favorite Answers</h2>
          <p>Name: ______________________________   Date: ______________</p>
          <p style={{ color: '#555' }}>Write your own answer to five of your favorite questions. Draw a picture if you like!</p>
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} style={{ border: '1px solid #999', borderRadius: 8, padding: 12, marginBottom: 12 }}>
              <p style={{ margin: 0, color: '#555' }}>Question {i + 1}: __________________________________________</p>
              <p style={{ marginTop: 24, borderTop: '1px dashed #bbb', paddingTop: 6, color: '#555' }}>My answer:</p>
              <div style={{ height: 40 }} />
            </div>
          ))}
          <Credit />
        </div>
      )}

      {doc === 'certificate' && (
        <div className="print-page">
          <div className="cert">
            <div className="ribbon">Certificate of Completion</div>
            <p style={{ marginTop: 14 }}>This certificate is proudly presented to:</p>
            <div className="name">{progress.studentName || 'My Bright Learner'}</div>
            <p>For completing</p>
            <h2 style={{ color: 'var(--coral)' }}>Bright Talk Adventure</h2>
            <p style={{ fontWeight: 700 }}>25 Daily Conversation Missions</p>
            <p style={{ marginTop: 18 }}>Missions completed: {progress.completedMissions.length} / {QUESTIONS.length} · Badges: {progress.earnedBadges.length} / 5</p>
            <p style={{ marginTop: 24 }}>Date: ______________     Teacher: ______________</p>
            <p style={{ marginTop: 14, fontWeight: 700 }}>Created by Bright EngMath</p>
          </div>
        </div>
      )}

      {doc === 'report' && (
        <div className="print-page">
          <h2 style={{ textAlign: 'center' }}>Progress Report</h2>
          <p><strong>Student:</strong> {progress.studentName || '______________________'}</p>
          <p><strong>Missions completed:</strong> {progress.completedMissions.length} / {QUESTIONS.length}</p>
          <p><strong>Worlds completed:</strong> {WORLDS.filter((w) => w.questionIds.every((id) => progress.completedMissions.includes(id))).length} / 5</p>
          <p><strong>Best quiz score:</strong> {progress.quizBestScore} / 25</p>
          <p><strong>Badges earned:</strong> {progress.earnedBadges.length} / 5</p>
          <p style={{ marginTop: 20 }}><strong>Teacher comment:</strong></p>
          <div style={{ border: '1px solid #999', borderRadius: 8, height: 90 }} />
          <Credit />
        </div>
      )}
    </div>
  );
}
