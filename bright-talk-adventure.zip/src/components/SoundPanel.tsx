import { useState } from 'react';
import { Volume2, X } from 'lucide-react';
import { useApp } from '../store/AppContext';
import type { SoundSettings } from '../types';

function Toggle({ id, label, checked, onChange }: {
  id: string; label: string; checked: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <div className="toggle-row">
      <label htmlFor={id}>{label}</label>
      <span className="switch">
        <input id={id} type="checkbox" checked={checked}
          onChange={(e) => onChange(e.target.checked)} />
        <span aria-hidden="true" />
      </span>
    </div>
  );
}

export function SoundPanel() {
  const { sound, updateSound } = useApp();
  const [open, setOpen] = useState(false);
  const set = (patch: Partial<SoundSettings>) => updateSound(patch);
  return (
    <>
      <button className="sound-fab no-print" aria-expanded={open}
        aria-label="Sound and animation settings" onClick={() => setOpen((o) => !o)}>
        {open ? <X size={22} /> : <Volume2 size={22} />}
      </button>
      {open && (
        <div className="sound-panel no-print" role="region" aria-label="Sound and animation settings">
          <h3>Sound & Motion</h3>
          <Toggle id="s-voice" label="Voice (read aloud)" checked={sound.voice} onChange={(v) => set({ voice: v })} />
          <Toggle id="s-fx" label="Effects" checked={sound.effects} onChange={(v) => set({ effects: v })} />
          <Toggle id="s-cel" label="Celebration sounds" checked={sound.celebration} onChange={(v) => set({ celebration: v })} />
          <Toggle id="s-anim" label="Animations" checked={sound.animations} onChange={(v) => set({ animations: v })} />
          <div style={{ height: 1, background: 'var(--line)', margin: '8px 0' }} />
          <Toggle id="s-mute" label="Mute all sound" checked={sound.muteAll} onChange={(v) => set({ muteAll: v })} />
        </div>
      )}
    </>
  );
}
