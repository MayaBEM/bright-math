import { useMemo, useState } from 'react';
import { Shuffle, RotateCcw, X, Volume2, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { WORLDS, WORLDS_BY_ID, worldOfQuestion } from '../data/worlds';
import { QUESTIONS_BY_ID } from '../data/questions';
import type { WorldId } from '../types';
import { useSpeech } from '../hooks/useSpeech';
import { useSfx } from '../hooks/useSfx';
import { QuestionArt } from '../art/QuestionArt';

const ALL = WORLDS.flatMap((w) => w.questionIds);

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function PickCardPage() {
  const nav = useNavigate();
  const { speak } = useSpeech();
  const { play } = useSfx();
  const [deck, setDeck] = useState<number[]>(() => shuffle(ALL));
  const [opened, setOpened] = useState<Set<number>>(new Set());
  const [filter, setFilter] = useState<WorldId | 'all'>('all');
  const [fs, setFs] = useState<number | null>(null);

  const visible = useMemo(
    () => (filter === 'all' ? deck : deck.filter((id) => worldOfQuestion(id).id === filter)),
    [deck, filter],
  );

  const flip = (id: number) => {
    play('flip');
    setOpened((prev) => new Set(prev).add(id));
  };

  const reset = () => { setOpened(new Set()); setDeck(shuffle(ALL)); };
  const reshuffle = () => { play('click'); setDeck((d) => shuffle(d)); };

  const fsQ = fs != null ? QUESTIONS_BY_ID[fs] : null;
  const fsWorld = fs != null ? worldOfQuestion(fs) : null;

  return (
    <div className="container">
      <button className="back-link" onClick={() => nav('/modes')}><ChevronLeft size={18} /> Back to Activities</button>
      <div className="page-head">
        <h1>Pick a Card</h1>
        <p>Tap a face-down card to reveal a conversation question. Great for one learner, a pair, or the whole class.</p>
      </div>

      <div className="card-toolbar no-print">
        <span className="chip">Opened: {opened.size} / {ALL.length}</span>
        <button className="btn btn--soft" onClick={reshuffle}><Shuffle size={18} /> Shuffle</button>
        <button className="btn btn--ghost" onClick={reset}><RotateCcw size={18} /> Reset Cards</button>
      </div>

      <div className="filter-row no-print" role="group" aria-label="Filter by world">
        <button className={filter === 'all' ? 'on' : ''} style={filter === 'all' ? { background: 'var(--ocean)' } : undefined}
          onClick={() => setFilter('all')}>All</button>
        {WORLDS.map((w) => (
          <button key={w.id} className={filter === w.id ? 'on' : ''}
            style={filter === w.id ? { background: w.color } : undefined}
            onClick={() => setFilter(w.id)}>{w.name}</button>
        ))}
      </div>

      <div className="deck">
        {visible.map((id) => {
          const w = worldOfQuestion(id);
          const isOpen = opened.has(id);
          const q = QUESTIONS_BY_ID[id];
          return (
            <button key={id} className={`flip${isOpen ? ' open' : ''}${isOpen ? ' used' : ''}`}
              style={{ ['--wc' as string]: w.color }}
              aria-label={isOpen ? `Card ${id}: ${q.question}` : `Face-down card ${id}. Tap to reveal.`}
              onClick={() => (isOpen ? setFs(id) : flip(id))}>
              <span className="flip__inner">
                <span className="flip__face flip__back" aria-hidden={isOpen}>?</span>
                <span className="flip__face flip__front" aria-hidden={!isOpen}>
                  <QuestionArt id={id} size={54} />
                  <span className="fn">#{id}</span>
                  <span style={{ fontSize: '.72rem', color: 'var(--ink-soft)', padding: '0 4px' }}>{q.question}</span>
                </span>
              </span>
            </button>
          );
        })}
      </div>
      {opened.size > 0 && <p className="notice no-print" style={{ maxWidth: 520, margin: '16px auto 0' }}>Tap an opened card again to show it full-screen.</p>}

      {fsQ && fsWorld && (
        <div className="fs-overlay" style={{ ['--wc' as string]: fsWorld.color }} role="dialog" aria-modal="true" aria-label="Question fullscreen">
          <button className="btn btn--ghost fs-close" onClick={() => setFs(null)}><X size={20} /> Close</button>
          <div className="fs-card">
            <div className="q-illus" style={{ color: fsWorld.color }}><QuestionArt id={fsQ.id} size={160} /></div>
            <div className="q-cat" style={{ color: fsWorld.color }}>{WORLDS_BY_ID[fsWorld.id].name} · #{fsQ.id}</div>
            <h2 className="q-text">{fsQ.question}</h2>
            <div className="starter" style={{ margin: '0 auto 18px' }}>{fsQ.sentenceStarter}</div>
            <button className="btn btn--primary btn--lg" onClick={() => speak(fsQ.question)}><Volume2 size={20} /> Listen</button>
          </div>
        </div>
      )}
    </div>
  );
}
