import type { World, WorldId } from '../types';

export const WORLDS: World[] = [
  {
    id: 'w1', name: 'All About Me', subtitle: 'Say who you are with pride.',
    color: 'var(--w1)', colorSoft: 'var(--w1-soft)',
    questionIds: [1, 2, 3, 12, 19],
    badge: { id: 'badge-w1', worldId: 'w1', title: 'Self Star', description: 'You can introduce yourself with confidence!' },
  },
  {
    id: 'w2', name: 'My Favorite Things', subtitle: 'Share what you love the most.',
    color: 'var(--w2)', colorSoft: 'var(--w2-soft)',
    questionIds: [4, 5, 6, 7, 11],
    badge: { id: 'badge-w2', worldId: 'w2', title: 'Favorites Star', description: 'You can talk about your favorite things!' },
  },
  {
    id: 'w3', name: 'Family and Friends', subtitle: 'Talk about the people you care about.',
    color: 'var(--w3)', colorSoft: 'var(--w3-soft)',
    questionIds: [8, 21, 9, 15, 18],
    badge: { id: 'badge-w3', worldId: 'w3', title: 'Friendship Star', description: 'You can describe your family and friends!' },
  },
  {
    id: 'w4', name: 'Feelings and My Day', subtitle: 'Tell us how you feel today.',
    color: 'var(--w4)', colorSoft: 'var(--w4-soft)',
    questionIds: [10, 13, 14, 16, 20],
    badge: { id: 'badge-w4', worldId: 'w4', title: 'Feelings Star', description: 'You can share your feelings and your day!' },
  },
  {
    id: 'w5', name: 'Dreams and Tomorrow', subtitle: 'Dream big and look ahead.',
    color: 'var(--w5)', colorSoft: 'var(--w5-soft)',
    questionIds: [17, 22, 23, 24, 25],
    badge: { id: 'badge-w5', worldId: 'w5', title: 'Dreamer Star', description: 'You can talk about your dreams and plans!' },
  },
];

export const WORLDS_BY_ID: Record<WorldId, World> = Object.fromEntries(
  WORLDS.map((w) => [w.id, w]),
) as Record<WorldId, World>;

export function worldOfQuestion(qid: number): World {
  return WORLDS.find((w) => w.questionIds.includes(qid)) ?? WORLDS[0];
}
