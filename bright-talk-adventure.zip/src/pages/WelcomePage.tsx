import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Play, GraduationCap, ArrowRight, Mic, Headphones, MessageCircle, Gamepad2, Printer, Users } from 'lucide-react';
import { useApp } from '../store/AppContext';
import { Brighty } from '../art/Brighty';

const FEATURES = [
  { icon: MessageCircle, color: 'var(--w1)', title: '25 speaking missions', text: 'Everyday conversation practice.' },
  { icon: Headphones, color: 'var(--w4)', title: 'Listening & pronunciation', text: 'Hear every question read aloud.' },
  { icon: Mic, color: 'var(--w2)', title: 'Model answers', text: 'Short and extended examples.' },
  { icon: Gamepad2, color: 'var(--w3)', title: 'Interactive games', text: 'Cards, wheel and quiz.' },
  { icon: Users, color: 'var(--w5)', title: 'Teacher-friendly tools', text: 'Classroom presentation mode.' },
  { icon: Printer, color: 'var(--ocean)', title: 'Printable activities', text: 'A4 worksheets and cards.' },
];

export function WelcomePage() {
  const { progress, setStudentName } = useApp();
  const nav = useNavigate();
  const [name, setName] = useState(progress.studentName);
  const [mode, setMode] = useState<'student' | 'classroom'>('student');
  const hasProgress = progress.completedMissions.length > 0 || progress.quizCompletedAt !== null;

  const start = () => {
    setStudentName(name.trim());
    nav(mode === 'classroom' ? '/classroom' : '/modes');
  };

  return (
    <div className="container">
      <section className="hero">
        <div>
          <h1 className="hero__title">Bright Talk <span className="accent">Adventure</span></h1>
          <p style={{ fontFamily: 'var(--font-head)', fontSize: '1.25rem', color: 'var(--ocean)', fontWeight: 600, margin: '6px 0 0' }}>
            25 Daily Conversation Missions
          </p>
          <p className="hero__sub">Speak, listen, think, and grow with every conversation.</p>

          <div className="mode-pills" role="group" aria-label="Choose a mode">
            <button className={mode === 'student' ? 'on' : ''} onClick={() => setMode('student')}
              aria-pressed={mode === 'student'}>Student Mode</button>
            <button className={mode === 'classroom' ? 'on' : ''} onClick={() => setMode('classroom')}
              aria-pressed={mode === 'classroom'}>Classroom Mode</button>
          </div>

          <div className="name-field">
            <label htmlFor="learner-name">What should we call you?</label>
            <input id="learner-name" value={name} maxLength={24} placeholder="Type your name (optional)"
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') start(); }} />
          </div>

          <div className="hero__buttons">
            <button className="btn btn--primary btn--lg" onClick={start}>
              <Play size={20} /> Start Adventure
            </button>
            <button className="btn btn--ghost btn--lg" onClick={() => { setStudentName(name.trim()); nav('/classroom'); }}>
              <GraduationCap size={20} /> Teacher Mode
            </button>
            {hasProgress && (
              <button className="btn btn--soft btn--lg" onClick={() => { setStudentName(name.trim()); nav('/map'); }}>
                Continue Learning <ArrowRight size={18} />
              </button>
            )}
          </div>
        </div>

        <div className="hero__art">
          <div style={{ textAlign: 'center' }}>
            <div className="hero__bubble">
              <p style={{ margin: 0, fontFamily: 'var(--font-head)', fontSize: '1.15rem', color: 'var(--ocean-deep)' }}>
                Hi! I'm Brighty. Let's talk together!
              </p>
            </div>
            <div className="floaty" style={{ marginTop: 18 }}>
              <Brighty mood="cheer" size={180} />
            </div>
          </div>
        </div>
      </section>

      <div className="features">
        {FEATURES.map((f) => (
          <div className="feature" key={f.title}>
            <span className="ic" style={{ background: f.color }}><f.icon size={22} /></span>
            <span><b>{f.title}</b><span>{f.text}</span></span>
          </div>
        ))}
      </div>
    </div>
  );
}
