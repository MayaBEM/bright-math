import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { AppProvider } from './store/AppContext';
import { Layout } from './components/Layout';
import { WelcomePage } from './pages/WelcomePage';
import { ModeSelectPage } from './pages/ModeSelectPage';
import { LearningMapPage } from './pages/LearningMapPage';
import { LearnSpeakPage } from './pages/LearnSpeakPage';
import { PickCardPage } from './pages/PickCardPage';
import { SpinSpeakPage } from './pages/SpinSpeakPage';
import { ClassroomPage } from './pages/ClassroomPage';
import { QuizPage } from './pages/QuizPage';
import { ProgressPage } from './pages/ProgressPage';
import { TeacherGuidePage } from './pages/TeacherGuidePage';
import { PrintPage } from './pages/PrintPage';

function ScrollTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

export function App() {
  return (
    <AppProvider>
      <HashRouter>
        <ScrollTop />
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<WelcomePage />} />
            <Route path="/modes" element={<ModeSelectPage />} />
            <Route path="/map" element={<LearningMapPage />} />
            <Route path="/learn" element={<LearnSpeakPage />} />
            <Route path="/learn/:id" element={<LearnSpeakPage />} />
            <Route path="/cards" element={<PickCardPage />} />
            <Route path="/spin" element={<SpinSpeakPage />} />
            <Route path="/classroom" element={<ClassroomPage />} />
            <Route path="/quiz" element={<QuizPage />} />
            <Route path="/progress" element={<ProgressPage />} />
            <Route path="/teacher-guide" element={<TeacherGuidePage />} />
            <Route path="/print" element={<PrintPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </HashRouter>
    </AppProvider>
  );
}
