import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Volume2, Snail, Repeat, Eye, Languages, Mic, Square, Play, Trash2,
  RotateCcw, CheckCircle2, ChevronLeft, ChevronRight, Check, Volume1,
} from 'lucide-react';
import { useApp } from '../store/AppContext';
import { WORLDS, worldOfQuestion } from '../data/worlds';
import { QUESTIONS_BY_ID } from '../data/questions';
import type { SpeakingChecklist, SupportLevel } from '../types';
import { useSpeech } from '../hooks/useSpeech';
import { useRecorder } from '../hooks/useRecorder';
import { useSfx } from '../hooks/useSfx';
import { QuestionArt } from '../art/QuestionArt';
import { Confetti } from '../art/Confetti';

const ORDER = WORLDS.flatMap((w) => w.questionIds);

const CHECK_ITEMS: { key: keyof SpeakingChecklist; label: string }[] = [
  { key: 'tried', label: 'I tried to answer.' },
  { key: 'fullSentence', label: 'I used a full sentence.' },
  { key: 'spokeClearly', label: 'I spoke clearly.' },
  { key: 'extraDetail', label: 'I added one extra detail.' },
];

const emptyCheck: SpeakingChecklist = { tried: false, fullSentence: false, spokeClearly: false, extraDetail: false };

export function LearnSpeakPage() {
  const { id } = useParams();
  const nav = useNavigate();
  const { progress, setSupportLevel, completeMission, isMissionComplete, setChecklist } = useApp();
  const { speak, supported: ttsOk } = useSpeech();
  const rec = useRecorder();
  const { play } = useSfx();

  const currentId = id ? Number(id) : ORDER[0];
  const q = QUESTIONS_BY_ID[currentId] ?? QUESTIONS_BY_ID[ORDER[0]];
  const world = worldOfQuestion(q.id);
  const level = progress.supportLevel;

  const [showExample, setShowExample] = useState(false);
  const [showThai, setShowThai] = useState(false);
  const [celebrate, setCelebrate] = useState(false);
  const check = progress.checklists[q.id] ?? emptyCheck;
  const idx = ORDER.indexOf(q.id);

  // Reset transient UI when the question changes.
  useEffect(() => {
    setShowExample(false); setShowThai(false); rec.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q.id]);

  const goto = (targetIdx: number) => {
    if (targetIdx < 0 || targetIdx >= ORDER.length) return;
    nav(`/learn/${ORDER[targetIdx]}`);
  };

  const celebrateTimer = useRef<number | null>(null);
  const onComplete = () => {
    play('success');
    const { badgeUnlocked } = completeMission(q.id);
    if (badgeUnlocked) {
      play('celebrate');
      setCelebrate(true);
      if (celebrateTimer.current) window.clearTimeout(celebrateTimer.current);
      celebrateTimer.current = window.setTimeout(() => setCelebrate(false), 2600);
    }
    // Advance to next mission if available.
    if (idx < ORDER.length - 1) window.setTimeout(() => goto(idx + 1), badgeUnlocked ? 1400 : 350);
  };
  useEffect(() => () => { if (celebrateTimer.current) window.clearTimeout(celebrateTimer.current); }, []);

  const setCheck = (key: keyof SpeakingChecklist) => {
    play('click');
    setChecklist(q.id, { ...check, [key]: !check[key] });
  };

  const done = isMissionComplete(q.id);
  const worldDoneCount = useMemo(
    () => world.questionIds.filter((qid) => progress.completedMissions.includes(qid)).length,
    [world, progress.completedMissions],
  );

  return (
    <div className="container ls-wrap" style={{ ['--wc' as string]: world.color }}>
      <Confetti show={celebrate} />
      <button className="back-link" onClick={() => nav('/map')}><ChevronLeft size={18} /> Back to Map</button>

      <div className="support-bar no-print" role="group" aria-label="Support level">
        <span className="lbl">Support:</span>
        <div className="seg">
          {([1, 2, 3] as SupportLevel[]).map((lv) => (
            <button key={lv} className={level === lv ? 'on' : ''} aria-pressed={level === lv}
              onClick={() => setSupportLevel(lv)}>
              {lv === 1 ? 'Picture' : lv === 2 ? 'Sentence' : 'Speak Freely'}
            </button>
          ))}
        </div>
      </div>

      <div className="card q-card">
        <div className="q-top">
          <span className="q-num" aria-hidden="true">{q.id}</span>
          <span>
            <span className="q-cat">{world.name}</span><br />
            <span style={{ color: 'var(--ink-soft)', fontWeight: 700, fontSize: '.82rem' }}>
              Mission {worldDoneCount}/5 in this world
            </span>
          </span>
          <span className="chip q-diff">{q.difficulty}</span>
        </div>

        {level === 1 && (
          <div className="q-illus"><QuestionArt id={q.id} size={130} /></div>
        )}

        <h2 className="q-text">{q.question}</h2>

        <div className="audio-row no-print">
          <button className="btn btn--soft" onClick={() => speak(q.question)} disabled={!ttsOk}>
            <Volume2 size={18} /> Listen
          </button>
          <button className="btn btn--soft" onClick={() => speak(q.question, { slow: true })} disabled={!ttsOk}>
            <Snail size={18} /> Slow
          </button>
          <button className="btn btn--soft" onClick={() => speak(q.question)} disabled={!ttsOk}>
            <Repeat size={18} /> Repeat
          </button>
        </div>
        {!ttsOk && <div className="notice">Read-aloud needs a browser that supports the Web Speech API (Chrome, Edge or Safari).</div>}

        {/* Sentence starter: shown in Levels 1 & 2 */}
        {level <= 2 && (
          <div className="starter">
            <button className="btn btn--icon" style={{ background: 'transparent', color: 'var(--ocean)', minHeight: 'auto', padding: 4, boxShadow: 'none' }}
              aria-label="Listen to the sentence starter" onClick={() => speak(q.sentenceStarter)}>
              <Volume1 size={18} />
            </button>{' '}{q.sentenceStarter}
          </div>
        )}

        {/* Vocabulary chips: shown in Levels 1 & 2 */}
        {level <= 2 && (
          <div className="vocab">
            {q.vocabulary.map((v) => (
              <span className="vchip" key={v}>
                {v}
                <button aria-label={`Say ${v}`} onClick={() => speak(v)} disabled={!ttsOk}><Volume2 size={15} /></button>
              </span>
            ))}
          </div>
        )}

        {/* Level 3: follow-up question shown up front */}
        {level === 3 && (
          <div className="followup">
            <span>Follow-up question</span>
            <p>{q.followUpQuestion}
              <button className="btn btn--icon" style={{ background: 'transparent', color: 'var(--ocean)', minHeight: 'auto', padding: 4, boxShadow: 'none' }}
                aria-label="Listen to the follow-up question" onClick={() => speak(q.followUpQuestion)}><Volume2 size={16} /></button>
            </p>
          </div>
        )}

        <div className="audio-row no-print">
          <button className="btn btn--ghost" aria-expanded={showExample} onClick={() => setShowExample((s) => !s)}>
            <Eye size={18} /> {showExample ? 'Hide Example' : 'Show Example'}
          </button>
          <button className="btn btn--ghost" aria-expanded={showThai} onClick={() => setShowThai((s) => !s)}>
            <Languages size={18} /> {showThai ? 'Hide Thai Hint' : 'Show Thai Hint'}
          </button>
        </div>

        {showExample && (
          <div className="example-box anim-fade">
            <h4>Short answer</h4>
            <p>{q.shortAnswer}
              <button className="btn btn--icon" style={{ background: 'var(--mint)', minHeight: 'auto', padding: 6, marginLeft: 8 }}
                aria-label="Listen to the short answer" onClick={() => speak(q.shortAnswer)}><Volume2 size={15} /></button>
            </p>
            <h4>Extended answer</h4>
            <p style={{ marginBottom: 0 }}>{q.extendedAnswer}
              <button className="btn btn--icon" style={{ background: 'var(--mint)', minHeight: 'auto', padding: 6, marginLeft: 8 }}
                aria-label="Listen to the extended answer" onClick={() => speak(q.extendedAnswer)}><Volume2 size={15} /></button>
            </p>
            {level !== 3 && (
              <>
                <h4 style={{ marginTop: 10 }}>Follow-up question</h4>
                <p style={{ marginBottom: 0 }}>{q.followUpQuestion}</p>
              </>
            )}
          </div>
        )}

        {showThai && (
          <div className="hint-box anim-fade" lang="th">{q.thaiHint}</div>
        )}

        {/* Recording */}
        <div className="record-row no-print" style={{ marginTop: 8 }}>
          {rec.state === 'unsupported' ? (
            <div className="notice">Recording needs a browser with the MediaRecorder API (Chrome, Edge, Firefox or Safari).</div>
          ) : rec.state === 'denied' ? (
            <div className="notice">Microphone permission was blocked. You can still practice out loud, or allow the microphone in your browser settings and try again.</div>
          ) : (
            <>
              {rec.state !== 'recording' && (
                <button className="btn btn--primary" onClick={rec.start}>
                  <Mic size={18} /> {rec.url ? 'Record Again' : 'Record My Answer'}
                </button>
              )}
              {rec.state === 'recording' && (
                <button className="btn" style={{ background: 'var(--coral)' }} onClick={rec.stop}>
                  <span className="rec-dot" /> <Square size={16} /> Stop
                </button>
              )}
              {rec.url && rec.state !== 'recording' && (
                <>
                  <audio src={rec.url} controls aria-label="Your recording" style={{ height: 40 }} />
                  <button className="btn btn--soft" onClick={() => { const a = new Audio(rec.url!); a.play(); }}>
                    <Play size={16} /> Play
                  </button>
                  <button className="btn btn--ghost" onClick={rec.reset}><Trash2 size={16} /> Delete</button>
                </>
              )}
            </>
          )}
        </div>
        <div className="notice no-print">Your recording stays in this browser only. It is never uploaded anywhere.</div>

        {/* Speaking checklist */}
        <h3 style={{ textAlign: 'center', margin: '18px 0 8px' }}>Speaking Checklist</h3>
        <div className="checklist">
          {CHECK_ITEMS.map((it) => {
            const on = check[it.key];
            return (
              <button key={it.key} className={`check-item${on ? ' on' : ''}`} aria-pressed={on}
                onClick={() => setCheck(it.key)}>
                <span className="box">{on && <Check size={18} />}</span>
                {it.label}
              </button>
            );
          })}
        </div>

        <div className="q-nav">
          <button className="btn btn--ghost" onClick={() => goto(idx - 1)} disabled={idx === 0}>
            <ChevronLeft size={18} /> Previous
          </button>
          <button className="btn btn--soft" onClick={rec.reset}><RotateCcw size={16} /> Try Again</button>
          <button className="btn btn--mint" onClick={onComplete}>
            <CheckCircle2 size={18} /> {done ? 'Completed' : 'Complete Mission'}
          </button>
          <button className="btn btn--ghost" onClick={() => goto(idx + 1)} disabled={idx === ORDER.length - 1}>
            Next <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
