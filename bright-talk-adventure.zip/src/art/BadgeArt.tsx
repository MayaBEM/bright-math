import type { WorldId } from '../types';

interface Props { world: WorldId; earned?: boolean; size?: number; className?: string; }

/** Original star-medal badge. Greyed out when not yet earned. */
export function BadgeArt({ world, earned = false, size = 84, className }: Props) {
  const color = earned ? `var(--${world})` : '#c9c2b4';
  const shine = earned ? '#fff' : '#e9e3d6';
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={className}
      xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M38 66l-8 26 20-10 20 10-8-26z" fill={color} opacity={earned ? 0.9 : 0.5} />
      <circle cx="50" cy="46" r="34" fill={color} />
      <circle cx="50" cy="46" r="34" fill="none" stroke={shine} strokeWidth="3" opacity=".6" />
      <path d="M50 28l6 12 13 2-9.5 9 2.3 13L50 57l-11.8 6 2.3-13-9.5-9 13-2z" fill={shine} />
    </svg>
  );
}
