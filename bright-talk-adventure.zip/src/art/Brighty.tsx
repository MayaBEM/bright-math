type Mood = 'happy' | 'cheer' | 'talk' | 'calm';

interface Props { mood?: Mood; size?: number; className?: string; title?: string; }

/** Brighty — an original friendly star mascot drawn as simple SVG. */
export function Brighty({ mood = 'happy', size = 120, className, title = 'Brighty the star' }: Props) {
  const mouth = {
    happy: 'M40 58c6 6 18 6 24 0',
    cheer: 'M38 54c8 12 24 12 32 0 -4 8 -12 12 -16 12 -4 0 -12 -4 -16 -12z',
    talk: 'M44 56c4 5 12 5 16 0 -2 6 -6 8 -8 8 -2 0 -6 -2 -8 -8z',
    calm: 'M42 58c5 3 15 3 20 0',
  }[mood];
  const filled = mood === 'cheer' || mood === 'talk';
  return (
    <svg width={size} height={size} viewBox="0 0 104 104" className={className}
      role="img" aria-label={title} xmlns="http://www.w3.org/2000/svg">
      <title>{title}</title>
      <defs>
        <linearGradient id="brightyBody" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fbe08a" />
          <stop offset="1" stopColor="#f4c531" />
        </linearGradient>
      </defs>
      <path d="M52 8c3.2 0 5.8 6.8 9 10 3.2 3.2 10.3 3.9 11.8 7.4 1.4 3.5-3.2 9-2.6 13.4.6 4.4 6 8.2 5.2 11.9-.8 3.7-7.6 4.8-10.3 8-2.7 3.2-3.1 10.1-6.6 12.2-3.5 2.1-9.2-1.6-13.4-1.6s-9.9 3.7-13.4 1.6c-3.5-2.1-3.9-9-6.6-12.2-2.7-3.2-9.5-4.3-10.3-8-.8-3.7 4.6-7.5 5.2-11.9.6-4.4-4-9.9-2.6-13.4 1.5-3.5 8.6-4.2 11.8-7.4 3.2-3.2 5.8-10 9-10z"
        fill="url(#brightyBody)" stroke="#e0a92c" strokeWidth="2.5" strokeLinejoin="round" />
      <circle cx="42" cy="46" r="5.2" fill="#2b2b2b" />
      <circle cx="62" cy="46" r="5.2" fill="#2b2b2b" />
      <circle cx="44" cy="44" r="1.7" fill="#fff" />
      <circle cx="64" cy="44" r="1.7" fill="#fff" />
      <path d={mouth} fill={filled ? '#8a3d34' : 'none'} stroke="#2b2b2b" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="34" cy="54" r="4" fill="#f4977f" opacity="0.65" />
      <circle cx="70" cy="54" r="4" fill="#f4977f" opacity="0.65" />
    </svg>
  );
}
