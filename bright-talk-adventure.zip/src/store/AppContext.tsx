import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type {
  StudentProgress, TeacherSettings, SoundSettings, SpeakingChecklist,
  SupportLevel, ClassroomStudent, WorldId,
} from '../types';
import { store, defaultProgress, defaultTeacher } from './storage';
import { WORLDS, worldOfQuestion } from '../data/worlds';

interface AppContextValue {
  progress: StudentProgress;
  teacher: TeacherSettings;
  sound: SoundSettings;
  // student progress actions
  setStudentName: (name: string) => void;
  setSupportLevel: (level: SupportLevel) => void;
  completeMission: (questionId: number) => { badgeUnlocked: WorldId | null };
  isMissionComplete: (questionId: number) => boolean;
  setChecklist: (questionId: number, c: SpeakingChecklist) => void;
  recordQuiz: (score: number, incorrect: number[]) => void;
  resetProgress: () => void;
  // teacher actions
  updateTeacher: (patch: Partial<TeacherSettings>) => void;
  addStudent: (name: string) => void;
  removeStudent: (id: string) => void;
  awardStar: (id: string) => void;
  markPicked: (id: string) => void;
  clearClassData: () => void;
  // sound actions
  updateSound: (patch: Partial<SoundSettings>) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [progress, setProgress] = useState<StudentProgress>(() => store.loadProgress());
  const [teacher, setTeacher] = useState<TeacherSettings>(() => store.loadTeacher());
  const [sound, setSound] = useState<SoundSettings>(() => store.loadSound());

  // Persist on change
  const first = useRef(true);
  useEffect(() => { store.saveProgress(progress); }, [progress]);
  useEffect(() => { store.saveTeacher(teacher); }, [teacher]);
  useEffect(() => {
    store.saveSound(sound);
    document.body.classList.toggle('no-anim', !sound.animations);
  }, [sound]);
  useEffect(() => { first.current = false; }, []);

  const setStudentName = useCallback((name: string) => {
    setProgress((p) => ({ ...p, studentName: name }));
  }, []);

  const setSupportLevel = useCallback((level: SupportLevel) => {
    setProgress((p) => ({ ...p, supportLevel: level }));
  }, []);

  const completeMission = useCallback((questionId: number): { badgeUnlocked: WorldId | null } => {
    let unlocked: WorldId | null = null;
    setProgress((p) => {
      const done = new Set(p.completedMissions);
      done.add(questionId);
      const world = worldOfQuestion(questionId);
      const practice = { ...p.practiceCount, [world.id]: (p.practiceCount[world.id] ?? 0) + 1 };
      const earned = new Set(p.earnedBadges);
      const worldDone = world.questionIds.every((id) => done.has(id));
      if (worldDone && !earned.has(world.badge.id)) {
        earned.add(world.badge.id);
        unlocked = world.id;
      }
      return {
        ...p,
        completedMissions: [...done].sort((a, b) => a - b),
        practiceCount: practice,
        earnedBadges: [...earned],
      };
    });
    return { badgeUnlocked: unlocked };
  }, []);

  const isMissionComplete = useCallback(
    (questionId: number) => progress.completedMissions.includes(questionId),
    [progress.completedMissions],
  );

  const setChecklist = useCallback((questionId: number, c: SpeakingChecklist) => {
    setProgress((p) => ({ ...p, checklists: { ...p.checklists, [questionId]: c } }));
  }, []);

  const recordQuiz = useCallback((score: number, incorrect: number[]) => {
    setProgress((p) => ({
      ...p,
      quizLastScore: score,
      quizBestScore: Math.max(p.quizBestScore, score),
      quizIncorrect: incorrect,
      quizCompletedAt: new Date().toISOString(),
    }));
  }, []);

  const resetProgress = useCallback(() => {
    store.clearProgress();
    setProgress(defaultProgress());
  }, []);

  const updateTeacher = useCallback((patch: Partial<TeacherSettings>) => {
    setTeacher((t) => ({ ...t, ...patch }));
  }, []);

  const addStudent = useCallback((name: string) => {
    const clean = name.trim();
    if (!clean) return;
    const s: ClassroomStudent = {
      id: `s_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name: clean, stars: 0, timesPicked: 0,
    };
    setTeacher((t) => ({ ...t, students: [...t.students, s] }));
  }, []);

  const removeStudent = useCallback((id: string) => {
    setTeacher((t) => ({ ...t, students: t.students.filter((s) => s.id !== id) }));
  }, []);

  const awardStar = useCallback((id: string) => {
    setTeacher((t) => ({
      ...t, students: t.students.map((s) => (s.id === id ? { ...s, stars: s.stars + 1 } : s)),
    }));
  }, []);

  const markPicked = useCallback((id: string) => {
    setTeacher((t) => ({
      ...t, students: t.students.map((s) => (s.id === id ? { ...s, timesPicked: s.timesPicked + 1 } : s)),
    }));
  }, []);

  const clearClassData = useCallback(() => {
    store.clearTeacher();
    setTeacher(defaultTeacher());
  }, []);

  const updateSound = useCallback((patch: Partial<SoundSettings>) => {
    setSound((s) => ({ ...s, ...patch }));
  }, []);

  const value = useMemo<AppContextValue>(() => ({
    progress, teacher, sound,
    setStudentName, setSupportLevel, completeMission, isMissionComplete, setChecklist,
    recordQuiz, resetProgress,
    updateTeacher, addStudent, removeStudent, awardStar, markPicked, clearClassData,
    updateSound,
  }), [progress, teacher, sound, setStudentName, setSupportLevel, completeMission,
    isMissionComplete, setChecklist, recordQuiz, resetProgress, updateTeacher, addStudent,
    removeStudent, awardStar, markPicked, clearClassData, updateSound]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

export const ALL_WORLDS = WORLDS;
